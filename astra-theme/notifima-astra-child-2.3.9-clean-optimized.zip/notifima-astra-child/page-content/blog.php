<?php
/**
 * Blog page content: editable Kadence block markup used when the page is created or rebuilt.
 * {{ref:…}} becomes the synced pattern of that name when the page is built.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_97d69f-11","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[170,28,80,28],"tabletPadding":[170,28,80,28],"mobilePadding":[140,18,56,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k phero"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_4f3aec-b9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap rv"} -->
<div class="wp-block-kadence-column kadence-column7_4f3aec-b9 kb-section-dir-vertical wrap rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_1b3837-80","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dmut)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"mobileMargin":[3,"","",""],"marginType":"px","className":"crumbs"} -->
<div class="kt-adv-heading7_1b3837-80 wp-block-kadence-advancedheading crumbs" data-kb-block="kb-adv-heading7_1b3837-80"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>/<span>Blog</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":1,"uniqueID":"7_1c0fe0-9d","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[66,42.64,38],"sizeType":"px","fontHeight":[69.96,45.1984,40.28],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.98,"tabletLetterSpacing":-1.2792,"mobileLetterSpacing":-1.14,"margin":[18,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)"} -->
<h1 class="kt-adv-heading7_1c0fe0-9d wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_1c0fe0-9d">News, tips and <mark class="kt-highlight">tutorials</mark></h1>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_cb96bf-fa","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[19.9,0,0,0],"tabletMargin":[20,"","",""],"marginType":"px","className":"lead"} -->
<p class="kt-adv-heading7_cb96bf-fa wp-block-kadence-advancedheading lead" data-kb-block="kb-adv-heading7_cb96bf-fa">Explore our blog for expert insights, tips and strategies on Notifima, and learn how to turn every stockout into a future sale.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:notifima/graphic {"name":"blog-cats"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_bf05af-78","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[32,28,104,28],"tabletPadding":[32,28,76,28],"mobilePadding":[32,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_bf26f1-ea","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_bf26f1-ea kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/rowlayout {"uniqueID":"7_b3e696-94","columns":2,"colLayout":"equal","columnsUnlocked":true,"firstColumnWidth":52.34,"secondColumnWidth":47.66,"tabletLayout":"row","columnGutter":"custom","customGutter":[20,"",""],"collapseGutter":"custom","customRowGutter":[20,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnsInnerHeight":true,"kbVersion":2,"className":"feat-post"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_1426b0-f9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_1426b0-f9 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"blog-fp-big"} /--></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_1559fd-8f","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"fp-list"} -->
<div class="wp-block-kadence-column kadence-column7_1559fd-8f kb-section-dir-vertical fp-list"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"blog-fp-s"} /-->

<!-- wp:notifima/graphic {"name":"blog-fp-s-2"} /-->

<!-- wp:notifima/graphic {"name":"blog-fp-s-3"} /-->

<!-- wp:notifima/graphic {"name":"blog-fp-s-4"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_a47eb5-d9","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","color":"var(\u002d\u002dast-global-color-3)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[40,0,0,0],"marginType":"px","className":"pager"} -->
<div class="kt-adv-heading7_a47eb5-d9 wp-block-kadence-advancedheading pager" data-kb-block="kb-adv-heading7_a47eb5-d9"><a class="on" href="#nf-pg-1">1</a><a href="#nf-pg-2">2</a><a href="#nf-pg-next">Next <svg aria-hidden="true" class="i"><use href="#arrow"></use></svg></a></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_db40d1-af","columns":2,"colLayout":"equal","columnsUnlocked":true,"firstColumnWidth":64.428,"secondColumnWidth":35.572,"tabletLayout":"row","columnGutter":"custom","customGutter":[24,"",""],"collapseGutter":"custom","customRowGutter":[24,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[36,40,36,40],"tabletPadding":[36,40,36,40],"mobilePadding":[26,22,26,22],"margin":[72,"",0,""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dp-50)","borderStyle":[{"top":["var(\u002d\u002dp-100)","solid",1],"right":["var(\u002d\u002dp-100)","solid",1],"bottom":["var(\u002d\u002dp-100)","solid",1],"left":["var(\u002d\u002dp-100)","solid",1],"unit":"px"}],"borderRadius":[32,32,32,32],"verticalAlignment":"middle","kbVersion":2,"className":"news-band rv"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_eb6f41-f9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_eb6f41-f9 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_dc26ab-3f","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[26,"",""],"sizeType":"px","fontHeight":[29.9,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.65,"margin":[0,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_dc26ab-3f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_dc26ab-3f">Get new guides in your inbox</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_306776-f5","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[6,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_306776-f5 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_306776-f5">One short email when we publish something useful. No spam, unsubscribe any time.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_b10a3b-7b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_b10a3b-7b kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"blog-news"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_fe32c4-f1","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dast-global-color-5)","columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec tint"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_7dc694-1d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_7dc694-1d kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_385827-ab","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_385827-ab kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_e9824e-c3","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.5,0,0,0],"tabletMargin":[7.4,"","",""],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_e9824e-c3 wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_e9824e-c3">FAQ</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_827cc2-ff","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_827cc2-ff wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_827cc2-ff">Blog <mark class="kt-highlight">questions</mark></h2>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_43ea7a-bf","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"borderStyle":[{"top":["var(\u002d\u002dast-global-color-7)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"margin":[48.1,0,0,0],"tabletMargin":[47.9,"","",""],"mobileMargin":[48,"","",""],"kbVersion":2,"className":"faq"} -->
<div class="wp-block-kadence-column kadence-column7_43ea7a-bf kb-section-dir-vertical faq"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"blog-qa"} /-->

<!-- wp:notifima/graphic {"name":"blog-qa-2"} /-->

<!-- wp:notifima/graphic {"name":"blog-qa-3"} /-->

<!-- wp:notifima/graphic {"name":"blog-qa-4"} /-->

<!-- wp:notifima/graphic {"name":"blog-qa-5"} /--></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
