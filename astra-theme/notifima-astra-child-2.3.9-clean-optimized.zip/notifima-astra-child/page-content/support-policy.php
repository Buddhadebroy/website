<?php
/**
 * Support Policy page content: editable Kadence block markup used when the page is created or rebuilt.
 * {{ref:…}} becomes the synced pattern of that name when the page is built.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_38c9db-e2","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[170,28,80,28],"tabletPadding":[170,28,80,28],"mobilePadding":[140,18,56,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k phero"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_7723ea-91","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap rv"} -->
<div class="wp-block-kadence-column kadence-column7_7723ea-91 kb-section-dir-vertical wrap rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_62e56d-f4","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dmut)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"mobileMargin":[3,"","",""],"marginType":"px","className":"crumbs"} -->
<div class="kt-adv-heading7_62e56d-f4 wp-block-kadence-advancedheading crumbs" data-kb-block="kb-adv-heading7_62e56d-f4"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>/<span>Support policy</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":1,"uniqueID":"7_8fda2d-53","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[66,42.64,38],"sizeType":"px","fontHeight":[69.96,45.1984,40.28],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.98,"tabletLetterSpacing":-1.2792,"mobileLetterSpacing":-1.14,"margin":[18,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)"} -->
<h1 class="kt-adv-heading7_8fda2d-53 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_8fda2d-53">Support <mark class="kt-highlight">policy</mark></h1>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_90d658-65","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[19.9,0,0,0],"tabletMargin":[20,"","",""],"marginType":"px","className":"lead"} -->
<p class="kt-adv-heading7_90d658-65 wp-block-kadence-advancedheading lead" data-kb-block="kb-adv-heading7_90d658-65">What our support covers, how to reach us and how fast we answer. Every paid plan comes with priority support for as long as your licence is active.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_d08320-69","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[26,0,0,0],"mobileMargin":[25.9,"","",""],"marginType":"px","className":"pills"} -->
<div class="kt-adv-heading7_d08320-69 wp-block-kadence-advancedheading pills" data-kb-block="kb-adv-heading7_d08320-69"><span><svg aria-hidden="true" class="i"><use href="#headphones"></use></svg>Priority support on every plan</span><span><svg aria-hidden="true" class="i"><use href="#clock"></use></svg>Monday to Friday, IST</span><span><svg aria-hidden="true" class="i"><use href="#globe"></use></svg>Help in English</span></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_1f1434-14","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[24,28,104,28],"tabletPadding":[24,28,76,28],"mobilePadding":[24,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_e38c4e-07","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_e38c4e-07 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_0f8b65-fd","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_0f8b65-fd kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_e0a773-a8","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.4,0,0,0],"tabletMargin":[7.5,"","",""],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_e0a773-a8 wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_e0a773-a8">What we cover</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_2f310f-9e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_2f310f-9e wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_2f310f-9e">Help with everything <mark class="kt-highlight">Notifima does</mark></h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_ed2117-f6","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[16,0,0,0],"marginType":"px","className":"intro"} -->
<p class="kt-adv-heading7_ed2117-f6 wp-block-kadence-advancedheading intro" data-kb-block="kb-adv-heading7_ed2117-f6">If it is part of Notifima, we will help you set it up, fix it or get the most out of it.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_3f2cff-78","columns":3,"colLayout":"equal","tabletLayout":"two-grid","mobileLayout":"row","columnGutter":"custom","customGutter":[20,"",""],"collapseGutter":"custom","customRowGutter":[20,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[52,"",0,""],"tabletMargin":[52.1,"","",""],"mobileMargin":[52,"","",""],"inheritMaxWidth":true,"columnsInnerHeight":true,"kbVersion":2,"className":"sixgrid"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_27a90d-b9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_27a90d-b9 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_7412a9-87","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_7412a9-87 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_7412a9-87">Installation and licence</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_f990fd-ff","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"tabletMargin":[8,"","",""],"mobileMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_f990fd-ff wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_f990fd-ff">Installing the plugin, activating your licence key and moving it to a new site.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_257cd7-3b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_257cd7-3b kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-2"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_bd7f58-34","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_bd7f58-34 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_bd7f58-34">Setup and settings</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_feba91-d6","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"tabletMargin":[8,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_feba91-d6 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_feba91-d6">Form placement, email templates, double opt-in, reCAPTCHA and Mailchimp sync.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_13d8c3-bd","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_13d8c3-bd kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-3"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_0c559f-3b","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_0c559f-3b wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0c559f-3b">Bug fixes</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_11b40b-73","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"mobileMargin":[8,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_11b40b-73 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_11b40b-73">Anything in Notifima that does not work as documented. We fix it in the next release.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_3cebd4-2d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_3cebd4-2d kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-4"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_2babe1-a9","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_2babe1-a9 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_2babe1-a9">Updates</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_ff865c-e4","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"tabletMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_ff865c-e4 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_ff865c-e4">New versions with features, fixes and WordPress and WooCommerce compatibility for your licence period.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_1432d8-4f","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_1432d8-4f kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-5"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_21d933-82","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_21d933-82 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_21d933-82">Compatibility checks</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_f22067-e4","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_f22067-e4 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_f22067-e4">Conflicts with popular themes and plugins. We find the cause and suggest a fix.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_ede630-b1","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_ede630-b1 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-6"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_e6102c-dd","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_e6102c-dd wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_e6102c-dd">How-to questions</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_aa68a0-24","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"mobileMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_aa68a0-24 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_aa68a0-24">Questions on using Notifima features, with links to the right guide in our documentation.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_0a4949-07","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dast-global-color-5)","columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec tint"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_9c9ab8-9d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_9c9ab8-9d kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/rowlayout {"uniqueID":"7_560005-cf","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"verticalAlignment":"middle","kbVersion":2,"className":"fz rv","anchor":"get-help"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_aecc53-d7","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_aecc53-d7 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_d0c505-3d","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_d0c505-3d wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_d0c505-3d">Getting help</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_370a48-69","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"tabletMargin":[11.55,"","",""],"mobileMargin":[10.75,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_370a48-69 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_370a48-69">Open a ticket, we take it from there</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_5f1b1b-62","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_5f1b1b-62 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_5f1b1b-62">The fastest way to a fix is a support ticket with the details we need. Free users can ask in the WordPress.org support forum.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_d6ed7f-db","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_d6ed7f-db kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_b0b32e-6b"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_b0b32e-6b"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Tell us your Notifima, WordPress and WooCommerce versions</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_051ae7-ec"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_051ae7-ec"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Describe the steps that show the problem</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_52575b-bc"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_52575b-bc"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Add a screenshot or a link to the page if you can</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_280f9e-ea","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_280f9e-ea kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-zz-art"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_826973-c8","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_65db94-c9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_65db94-c9 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_66465d-1b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_66465d-1b kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_bd1e7a-87","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.4,0,0,0],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_bd1e7a-87 wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_bd1e7a-87">Response times</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_b064ea-b2","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_b064ea-b2 wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_b064ea-b2">How fast <mark class="kt-highlight">we answer</mark></h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_a9c5ae-25","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[16,0,0,0],"marginType":"px","className":"intro"} -->
<p class="kt-adv-heading7_a9c5ae-25 wp-block-kadence-advancedheading intro" data-kb-block="kb-adv-heading7_a9c5ae-25">Times are for the first reply on working days, Monday to Friday, Indian Standard Time.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_f5ab85-f0","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"margin":[48,0,0,0],"kbVersion":2,"className":"cmp rv"} -->
<div class="wp-block-kadence-column kadence-column7_f5ab85-f0 kb-section-dir-vertical cmp rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-nfg"} /--></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_537d93-b2","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[14.5,"",""],"sizeType":"px","fontHeight":[23.925,"",""],"fontHeightType":"px","fontWeight":"400","margin":[16,0,0,0],"marginType":"px","className":"cmp-note"} -->
<p class="kt-adv-heading7_537d93-b2 wp-block-kadence-advancedheading cmp-note" data-kb-block="kb-adv-heading7_537d93-b2">Support is included while your licence is active. Renew to keep updates and priority support.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_6d1ffc-7d","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dast-global-color-5)","columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec tint"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_8daaf3-c4","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_8daaf3-c4 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_c07870-16","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_c07870-16 kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_4f04c6-6f","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.5,0,0,0],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_4f04c6-6f wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_4f04c6-6f">Not covered</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_88e3d1-57","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_88e3d1-57 wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_88e3d1-57">Where our support <mark class="kt-highlight">stops</mark></h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_b71e73-e5","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[16,0,0,0],"marginType":"px","className":"intro"} -->
<p class="kt-adv-heading7_b71e73-e5 wp-block-kadence-advancedheading intro" data-kb-block="kb-adv-heading7_b71e73-e5">We are happy to point you in the right direction, but these are outside our support.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_189fad-aa","columns":3,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[20,"",""],"collapseGutter":"custom","customRowGutter":[20,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[52,"",0,""],"tabletMargin":[52.1,"","",""],"mobileMargin":[52,"","",""],"inheritMaxWidth":true,"columnsInnerHeight":true,"kbVersion":2,"className":"sixgrid vals"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_81d019-a8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_81d019-a8 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-7"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_42fdb3-27","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_42fdb3-27 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_42fdb3-27">Custom development</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_2c589e-c0","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"tabletMargin":[8,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_2c589e-c0 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_2c589e-c0">New features built only for your store, custom code and design changes beyond Notifima's settings.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_362fe8-f3","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_362fe8-f3 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-8"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_ece2fa-4d","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_ece2fa-4d wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_ece2fa-4d">Other plugins and themes</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_08217d-07","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"tabletMargin":[8,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_08217d-07 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_08217d-07">Problems that come from another plugin, a theme or custom code, once we have found the cause.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_290d85-ba","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_290d85-ba kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-9"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_f9de93-ea","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_f9de93-ea wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_f9de93-ea">Hosting and email delivery</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_0549af-18","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"tabletMargin":[8,"","",""],"mobileMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_0549af-18 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0549af-18">Server setup, email sending limits and spam filtering at your host or mail provider.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_f92dd2-b1","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_86abd6-d9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_86abd6-d9 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_6df3c6-4d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_6df3c6-4d kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_dd05db-c5","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.4,0,0,0],"tabletMargin":[7.5,"","",""],"mobileMargin":[6.5,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_dd05db-c5 wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_dd05db-c5">FAQ</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_9457ec-af","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"tabletMargin":[13.9,"","",""],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_9457ec-af wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_9457ec-af">Support <mark class="kt-highlight">questions</mark></h2>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_f6f9bf-dc","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"borderStyle":[{"top":["var(\u002d\u002dast-global-color-7)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"margin":[48,0,0,0],"kbVersion":2,"className":"faq"} -->
<div class="wp-block-kadence-column kadence-column7_f6f9bf-dc kb-section-dir-vertical faq"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-qa"} /-->

<!-- wp:notifima/graphic {"name":"support-qa-2"} /-->

<!-- wp:notifima/graphic {"name":"support-qa-3"} /-->

<!-- wp:notifima/graphic {"name":"support-qa-4"} /-->

<!-- wp:notifima/graphic {"name":"support-qa-5"} /--></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
