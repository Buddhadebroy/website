<?php
/**
 * Release Notes page content: editable Kadence block markup used when the page is created or rebuilt.
 * {{ref:…}} becomes the synced pattern of that name when the page is built.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_938dda-63","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[170,28,80,28],"tabletPadding":[170,28,80,28],"mobilePadding":[140,18,56,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k phero"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_941a6c-2d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap rv"} -->
<div class="wp-block-kadence-column kadence-column7_941a6c-2d kb-section-dir-vertical wrap rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_fca38a-f5","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dmut)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"mobileMargin":[3,"","",""],"marginType":"px","className":"crumbs"} -->
<div class="kt-adv-heading7_fca38a-f5 wp-block-kadence-advancedheading crumbs" data-kb-block="kb-adv-heading7_fca38a-f5"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>/<span>Release notes</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":1,"uniqueID":"7_baf804-d2","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[66,42.64,38],"sizeType":"px","fontHeight":[69.96,45.1984,40.28],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.98,"tabletLetterSpacing":-1.2792,"mobileLetterSpacing":-1.14,"margin":[18,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)"} -->
<h1 class="kt-adv-heading7_baf804-d2 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_baf804-d2">Release <mark class="kt-highlight">notes</mark></h1>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_5cc378-37","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[19.9,0,0,0],"tabletMargin":[20,"","",""],"marginType":"px","className":"lead"} -->
<p class="kt-adv-heading7_5cc378-37 wp-block-kadence-advancedheading lead" data-kb-block="kb-adv-heading7_5cc378-37">Every update, fix and improvement to Notifima, newest first. Current version is [nf_version].</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->


