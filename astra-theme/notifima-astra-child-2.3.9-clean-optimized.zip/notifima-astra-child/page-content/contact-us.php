<?php
/**
 * Contact Us page content: editable Kadence block markup used when the page is created or rebuilt.
 * {{ref:…}} becomes the synced pattern of that name when the page is built.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_f27781-1c","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[170,28,80,28],"tabletPadding":[170,28,80,28],"mobilePadding":[140,18,56,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k phero"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_d31f68-a8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap rv"} -->
<div class="wp-block-kadence-column kadence-column7_d31f68-a8 kb-section-dir-vertical wrap rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_c35862-39","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dmut)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"mobileMargin":[3,"","",""],"marginType":"px","className":"crumbs"} -->
<div class="kt-adv-heading7_c35862-39 wp-block-kadence-advancedheading crumbs" data-kb-block="kb-adv-heading7_c35862-39"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>/<span>Contact us</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":1,"uniqueID":"7_0d8d66-1e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[66,42.64,38],"sizeType":"px","fontHeight":[69.96,45.1984,40.28],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.98,"tabletLetterSpacing":-1.2792,"mobileLetterSpacing":-1.14,"margin":[18,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)"} -->
<h1 class="kt-adv-heading7_0d8d66-1e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0d8d66-1e">Get in <mark class="kt-highlight">touch</mark></h1>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_899027-da","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[19.9,0,0,0],"tabletMargin":[20,"","",""],"marginType":"px","className":"lead"} -->
<p class="kt-adv-heading7_899027-da wp-block-kadence-advancedheading lead" data-kb-block="kb-adv-heading7_899027-da">Questions about plans, partnerships or a problem on your store? Pick the fastest way to reach the Notifima team.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_38a89b-a5","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[26,0,0,0],"marginType":"px","className":"pills"} -->
<div class="kt-adv-heading7_38a89b-a5 wp-block-kadence-advancedheading pills" data-kb-block="kb-adv-heading7_38a89b-a5"><span><svg aria-hidden="true" class="i"><use href="#clock"></use></svg>Reply within 1 working day</span><span><svg aria-hidden="true" class="i"><use href="#pin"></use></svg>Kolkata, India</span><span><svg aria-hidden="true" class="i"><use href="#building"></use></svg>A MultiVendorX company</span></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_0d5ed6-b1","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[76,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_6f9faa-73","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_6f9faa-73 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/rowlayout {"uniqueID":"7_e0c423-24","columns":3,"colLayout":"equal","tabletLayout":"two-grid","mobileLayout":"row","columnGutter":"custom","customGutter":[20,"",""],"collapseGutter":"custom","customRowGutter":[20,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnsInnerHeight":true,"kbVersion":2,"className":"sixgrid"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_2ac25b-5e","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_2ac25b-5e kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"contact-chipi"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_337d9c-79","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_337d9c-79 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_337d9c-79">Sales and partnerships</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_18274c-16","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"tabletMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_18274c-16 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_18274c-16">Plans, agency pricing, bulk licences and partnerships.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_cee744-fa","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[18.1,0,0,0],"tabletMargin":[18,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_cee744-fa wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_cee744-fa"><a class="link" href="mailto:contact@notifima.com">contact@notifima.com <svg aria-hidden="true" class="i"><use href="#arrow"></use></svg></a></p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_e9395e-19","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_e9395e-19 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"contact-chipi-2"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_df7f52-d9","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_df7f52-d9 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_df7f52-d9">Technical support</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_01f09e-a4","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"tabletMargin":[8.1,"","",""],"mobileMargin":[8,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_01f09e-a4 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_01f09e-a4">Already a customer? Open a ticket for the quickest help.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_0a5a6f-d6","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[18.1,0,0,0],"tabletMargin":[18,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_0a5a6f-d6 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0a5a6f-d6"><a class="link" href="#nf-support">Create a support ticket <svg aria-hidden="true" class="i"><use href="#arrow"></use></svg></a></p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_d1db34-00","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_d1db34-00 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"support-chipi-6"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_2ba62b-d0","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_2ba62b-d0 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_2ba62b-d0">Documentation</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_dcea4b-2c","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_dcea4b-2c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_dcea4b-2c">Step-by-step guides for setup, settings and integrations.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_2c247c-4c","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[18.1,0,0,0],"tabletMargin":[18,"","",""],"mobileMargin":[18.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_2c247c-4c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_2c247c-4c"><a class="link" href="#nf-docs">Read the docs <svg aria-hidden="true" class="i"><use href="#arrow"></use></svg></a></p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_24dcb0-a2","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dast-global-color-5)","columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec tint"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_d1943c-97","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_d1943c-97 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/rowlayout {"uniqueID":"7_a303fa-dd","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"verticalAlignment":"middle","kbVersion":2,"className":"fz rv","anchor":"message"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_a33a98-2b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_a33a98-2b kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_d96eb9-cb","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_d96eb9-cb wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_d96eb9-cb">Write to us</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_288ce5-60","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"mobileMargin":[10.85,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_288ce5-60 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_288ce5-60">Send us a message</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_c9cfd5-f0","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_c9cfd5-f0 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_c9cfd5-f0">Tell us what you need and we will get back to you by email, usually on the same or next working day.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_3ab9aa-27","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_3ab9aa-27 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_a60935-82"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_a60935-82"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Sales questions answered by the Notifima team</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_54c93c-37"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_54c93c-37"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">No newsletter sign-up, no spam</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_08d33f-29"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_08d33f-29"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Notifima, BD 404 Ground Floor, Sector 1, Salt Lake City, Kolkata, India</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_697d43-c8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_697d43-c8 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"contact-zz-art"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_00c95a-48","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_e588cd-3b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_e588cd-3b kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_9f3f75-4f","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_9f3f75-4f kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_24595d-bf","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.5,0,0,0],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_24595d-bf wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_24595d-bf">FAQ</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_e96add-9f","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[13.9,0,0,0],"tabletMargin":[14,"","",""],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_e96add-9f wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_e96add-9f">Before you <mark class="kt-highlight">write</mark></h2>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_b70fe4-d7","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"borderStyle":[{"top":["var(\u002d\u002dast-global-color-7)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"margin":[48,0,0,0],"kbVersion":2,"className":"faq"} -->
<div class="wp-block-kadence-column kadence-column7_b70fe4-d7 kb-section-dir-vertical faq"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"contact-qa"} /-->

<!-- wp:notifima/graphic {"name":"contact-qa-2"} /-->

<!-- wp:notifima/graphic {"name":"contact-qa-3"} /-->

<!-- wp:notifima/graphic {"name":"contact-qa-4"} /--></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
