<?php
/**
 * About Us page content: editable Kadence block markup used when the page is created or rebuilt.
 * {{ref:…}} becomes the synced pattern of that name when the page is built.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_8d70c1-38","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[170,28,80,28],"tabletPadding":[170,28,80,28],"mobilePadding":[140,18,56,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k phero"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_36f1ab-11","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap rv"} -->
<div class="wp-block-kadence-column kadence-column7_36f1ab-11 kb-section-dir-vertical wrap rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_bc7471-0a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dmut)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"mobileMargin":[3,"","",""],"marginType":"px","className":"crumbs"} -->
<div class="kt-adv-heading7_bc7471-0a wp-block-kadence-advancedheading crumbs" data-kb-block="kb-adv-heading7_bc7471-0a"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>/<span>About us</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":1,"uniqueID":"7_de5744-ac","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[66,42.64,38],"sizeType":"px","fontHeight":[69.96,45.1984,40.28],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.98,"tabletLetterSpacing":-1.2792,"mobileLetterSpacing":-1.14,"margin":[18,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)"} -->
<h1 class="kt-adv-heading7_de5744-ac wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_de5744-ac">We turn <mark class="kt-highlight">"out of stock"</mark><br/>into what's next</h1>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_f3fb56-90","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[20,0,0,0],"marginType":"px","className":"lead"} -->
<p class="kt-adv-heading7_f3fb56-90 wp-block-kadence-advancedheading lead" data-kb-block="kb-adv-heading7_f3fb56-90">Notifima helps WooCommerce stores keep every interested shopper, even when the shelf is empty. Here is what drives us and where we are heading.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_f98847-6a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[26,0,0,0],"marginType":"px","className":"pills"} -->
<div class="kt-adv-heading7_f98847-6a wp-block-kadence-advancedheading pills" data-kb-block="kb-adv-heading7_f98847-6a"><span><svg aria-hidden="true" class="i"><use href="#store"></use></svg>Built for WooCommerce</span><span><svg aria-hidden="true" class="i"><use href="#building"></use></svg>A MultiVendorX company</span><span><svg aria-hidden="true" class="i"><use href="#pin"></use></svg>Kolkata, India</span></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_12d964-ab","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[24,28,40,28],"tabletPadding":[24,28,40,28],"mobilePadding":[24,18,40,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_104b75-b9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_104b75-b9 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/rowlayout {"uniqueID":"7_69c73b-3f","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"verticalAlignment":"middle","kbVersion":2,"className":"fz rv","anchor":"vision"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_67b63c-16","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_67b63c-16 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_663fe8-e9","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_663fe8-e9 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_663fe8-e9">Our vision</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_f47b59-1e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.55,0,0,0],"mobileMargin":[10.75,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_f47b59-1e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_f47b59-1e">No sale lost to an empty shelf</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_31b980-05","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"tabletMargin":[13.9,"","",""],"mobileMargin":[14,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_31b980-05 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_31b980-05">We want to transform eCommerce by eliminating lost sales and creating meaningful connections between businesses and customers through intelligent inventory tools.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_66c77b-08","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_66c77b-08 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_36c68b-53"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_36c68b-53"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Stockouts become revenue opportunities, not lost sales</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_b7d0da-d6"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_b7d0da-d6"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Disappointment turns into anticipation</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_3401fa-89"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_3401fa-89"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Every product listing earns, whatever its stock status</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_b12a06-fc","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_b12a06-fc kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"about-zz-art"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_1a8983-01","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"verticalAlignment":"middle","kbVersion":2,"className":"fz rev rv","anchor":"mission"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_82a373-b2","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_82a373-b2 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_366ee9-92","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_366ee9-92 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_366ee9-92">Our mission</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_f87820-e5","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"tabletMargin":[11.55,"","",""],"mobileMargin":[10.75,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_f87820-e5 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_f87820-e5">Inventory gaps into revenue</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_ca73b7-05","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_ca73b7-05 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_ca73b7-05"><b style="color:var(--head);font-weight:500">Notifima</b> helps WooCommerce merchants convert inventory challenges into revenue with seamless notifications that keep customers engaged and businesses profitable.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_15b162-6e","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22.1,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_15b162-6e kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_cdc7dc-7b"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_cdc7dc-7b"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Intuitive, powerful tools that bridge inventory and customer experience</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_1883be-fa"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_1883be-fa"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">"Out of stock" never means "lost customer" again</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_937ecc-89"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_937ecc-89"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Relationships that last even when fulfilment has to wait</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_285f9a-a8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_285f9a-a8 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"about-zz-art-2"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_7e11f0-c1","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"verticalAlignment":"middle","kbVersion":2,"className":"fz rv","anchor":"future"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_cb6902-e9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_cb6902-e9 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_da1b1e-c9","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_da1b1e-c9 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_da1b1e-c9">Future plans</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_d578ca-a2","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"tabletMargin":[11.55,"","",""],"mobileMargin":[10.85,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_d578ca-a2 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_d578ca-a2">From plugin to commerce suite</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_0d10d0-c3","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"tabletMargin":[13.9,"","",""],"mobileMargin":[14,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_0d10d0-c3 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0d10d0-c3">Notifima will grow from a focused WooCommerce plugin into a complete commerce ecosystem, while staying true to our core: turning inventory challenges into revenue for online retailers worldwide.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_37de75-d1","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_37de75-d1 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"about-zz-art-3"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_28d5ab-02","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dast-global-color-5)","columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec tint"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_77e8c5-dc","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_77e8c5-dc kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_7b461f-ee","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_7b461f-ee kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_ab09f8-5a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.4,0,0,0],"mobileMargin":[6.5,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_ab09f8-5a wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_ab09f8-5a">How we work</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_40b3eb-b9","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"mobileMargin":[13.9,"","",""],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_40b3eb-b9 wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_40b3eb-b9">The values behind <mark class="kt-highlight">every release</mark></h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_e66bc9-a5","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[16,0,0,0],"marginType":"px","className":"intro"} -->
<p class="kt-adv-heading7_e66bc9-a5 wp-block-kadence-advancedheading intro" data-kb-block="kb-adv-heading7_e66bc9-a5">Notifima turns your store into a customer engagement powerhouse, unlocking opportunities you never knew existed. Here's how we get there.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_b0390e-fa","columns":3,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[20,"",""],"collapseGutter":"custom","customRowGutter":[20,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[52,"",0,""],"inheritMaxWidth":true,"columnsInnerHeight":true,"kbVersion":2,"className":"sixgrid vals"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_730286-35","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_730286-35 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"about-chipi"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_337957-31","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_337957-31 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_337957-31">Prioritize customer success</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_38615d-6e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"tabletMargin":[8,"","",""],"mobileMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_38615d-6e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_38615d-6e">We put customers first, continually improving Notifima with top-notch support and solutions tailored to evolving needs.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_d399ec-70","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_d399ec-70 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"about-chipi-2"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_aba024-d4","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_aba024-d4 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_aba024-d4">Innovate with purpose</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_a85c2e-1a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"tabletMargin":[8,"","",""],"mobileMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_a85c2e-1a wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_a85c2e-1a">We innovate boldly, using your feedback to refine Notifima, stay ahead of industry trends and push the limits of inventory management.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_dc68b3-e2","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_dc68b3-e2 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"about-chipi-3"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_1e44c0-7e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_1e44c0-7e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_1e44c0-7e">Embrace challenges</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_4ecf29-93","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_4ecf29-93 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_4ecf29-93">We tackle challenges head-on, building features that help businesses grow and keep strong customer relationships.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_32d268-3d","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_cfa343-c8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_cfa343-c8 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_03d2fc-e9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_03d2fc-e9 kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_75c6cc-8f","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.5,0,0,0],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_75c6cc-8f wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_75c6cc-8f">FAQ</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_f95981-de","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_f95981-de wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_f95981-de">About <mark class="kt-highlight">Notifima</mark></h2>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_d6344b-32","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"borderStyle":[{"top":["var(\u002d\u002dast-global-color-7)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"margin":[48.1,0,0,0],"tabletMargin":[48,"","",""],"kbVersion":2,"className":"faq"} -->
<div class="wp-block-kadence-column kadence-column7_d6344b-32 kb-section-dir-vertical faq"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"about-qa"} /-->

<!-- wp:notifima/graphic {"name":"about-qa-2"} /-->

<!-- wp:notifima/graphic {"name":"about-qa-3"} /-->

<!-- wp:notifima/graphic {"name":"about-qa-4"} /-->

<!-- wp:notifima/graphic {"name":"about-qa-5"} /-->

<!-- wp:notifima/graphic {"name":"about-qa-6"} /--></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
