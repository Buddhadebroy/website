<?php
/**
 * Features page content: editable Kadence block markup used when the page is created or rebuilt.
 * {{ref:…}} becomes the synced pattern of that name when the page is built.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_158fd4-66","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[170,28,80,28],"tabletPadding":[170,28,80,28],"mobilePadding":[140,18,56,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k phero"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_9fb1dd-2f","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap rv"} -->
<div class="wp-block-kadence-column kadence-column7_9fb1dd-2f kb-section-dir-vertical wrap rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_bf5f24-05","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dmut)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"mobileMargin":[3,"","",""],"marginType":"px","className":"crumbs"} -->
<div class="kt-adv-heading7_bf5f24-05 wp-block-kadence-advancedheading crumbs" data-kb-block="kb-adv-heading7_bf5f24-05"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>/<span>Features</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":1,"uniqueID":"7_0cc387-1d","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[66,42.64,38],"sizeType":"px","fontHeight":[69.96,45.1984,40.28],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.98,"tabletLetterSpacing":-1.2792,"mobileLetterSpacing":-1.14,"margin":[18,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)"} -->
<h1 class="kt-adv-heading7_0cc387-1d wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0cc387-1d">From waitlist to cart in <mark class="kt-highlight">one click</mark></h1>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_8cd952-9e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[19.9,0,0,0],"tabletMargin":[20,"","",""],"marginType":"px","className":"lead"} -->
<p class="kt-adv-heading7_8cd952-9e wp-block-kadence-advancedheading lead" data-kb-block="kb-adv-heading7_8cd952-9e">Everything Notifima does to turn "Out of Stock" into your next sale, from the first signup to the moment they buy.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_21fa22-f1","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[26,0,0,0],"mobileMargin":[26.1,"","",""],"marginType":"px","className":"pills"} -->
<div class="kt-adv-heading7_21fa22-f1 wp-block-kadence-advancedheading pills" data-kb-block="kb-adv-heading7_21fa22-f1"><span><svg aria-hidden="true" class="i"><use href="#checks"></use></svg>Double opt-in</span><span><svg aria-hidden="true" class="i"><use href="#shield"></use></svg>reCAPTCHA integration</span><span><svg aria-hidden="true" class="i"><use href="#send"></use></svg>Mailchimp</span><span><svg aria-hidden="true" class="i"><use href="#mailoff"></use></svg>Quick unsubscribe</span><span><svg aria-hidden="true" class="i"><use href="#ban"></use></svg>Ban spam emails</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedbtn {"uniqueID":"7_8e379f-35","hAlign":"center","margin":[{"desk":[30,0,0,0],"tablet":["","","",""],"mobile":["","","",""]}],"className":"btns"} -->
<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns7_8e379f-35 btns"><!-- wp:kadence/singlebtn {"uniqueID":"7_b189df-b0","text":"Get a Demo","link":"#nf-demo","icon":"fe_arrowRight","typography":[{"size":[16,"",""],"sizeType":"px","lineHeight":[26.4,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"500","variant":"","subset":"","loadGoogle":true,"textTransform":""}],"color":"var(\u002d\u002dast-global-color-4)","background":"var(\u002d\u002dast-global-color-0)","colorHover":"var(\u002d\u002dast-global-color-4)","backgroundHover":"var(\u002d\u002dp-d)","padding":[11.8,26,11.8,26],"paddingUnit":"px","borderRadius":[999,999,999,999],"borderStyle":[{"top":["","solid",1],"right":["","solid",1],"bottom":["","solid",1],"left":["","solid",1],"unit":"px"}],"borderHoverStyle":[{"top":["","solid",1],"right":["","solid",1],"bottom":["","solid",1],"left":["","solid",1],"unit":"px"}],"displayShadow":true,"shadow":[{"color":"#852aff","opacity":0.8,"spread":-10,"blur":24,"hOffset":0,"vOffset":10,"inset":false}],"className":"btn btn-p"} /-->

<!-- wp:kadence/singlebtn {"uniqueID":"7_e326ec-f7","text":"Buy Now","link":"<?php echo esc_url( home_url( '/pricing/' ) ); ?>","typography":[{"size":[16,"",""],"sizeType":"px","lineHeight":[26.4,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"500","variant":"","subset":"","loadGoogle":true,"textTransform":""}],"color":"var(\u002d\u002dast-global-color-2)","background":"var(\u002d\u002dast-global-color-4)","colorHover":"var(\u002d\u002dast-global-color-2)","backgroundHover":"var(\u002d\u002dast-global-color-4)","padding":[11.8,26,11.8,26],"paddingUnit":"px","borderRadius":[999,999,999,999],"borderStyle":[{"top":["var(\u002d\u002dast-global-color-7)","solid",1],"right":["var(\u002d\u002dast-global-color-7)","solid",1],"bottom":["var(\u002d\u002dast-global-color-7)","solid",1],"left":["var(\u002d\u002dast-global-color-7)","solid",1],"unit":"px"}],"borderHoverStyle":[{"top":["var(\u002d\u002dast-global-color-2)","solid",1],"right":["var(\u002d\u002dast-global-color-2)","solid",1],"bottom":["var(\u002d\u002dast-global-color-2)","solid",1],"left":["var(\u002d\u002dast-global-color-2)","solid",1],"unit":"px"}],"className":"btn btn-g"} /--></div>
<!-- /wp:kadence/advancedbtn --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_d7fe9f-00","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[40,28,104,28],"tabletPadding":[40,28,76,28],"mobilePadding":[40,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_9908c5-9e","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_9908c5-9e kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_419cd0-bb","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_419cd0-bb kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_cdd4cd-af","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.4,0,0,0],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_cdd4cd-af wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_cdd4cd-af">Back in stock, back in business</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_24a896-c4","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_24a896-c4 wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_24a896-c4">Stock <mark class="kt-highlight">out</mark>? Sales <mark class="kt-highlight">in</mark>.</h2>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_e17f23-c2","columns":3,"colLayout":"equal","tabletLayout":"two-grid","mobileLayout":"row","columnGutter":"custom","customGutter":[20,"",""],"collapseGutter":"custom","customRowGutter":[20,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[52,"",0,""],"tabletMargin":[51.9,"","",""],"mobileMargin":[52,"","",""],"inheritMaxWidth":true,"columnsInnerHeight":true,"kbVersion":2,"className":"sixgrid","anchor":"alerts"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_814f88-82","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_814f88-82 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"home-chipi-2"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_d576b5-59","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_d576b5-59 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_d576b5-59">Automated stock notifications</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_9ffc10-8d","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"mobileMargin":[8,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_9ffc10-8d wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_9ffc10-8d">Instantly alert customers when their products are back in stock with professional, branded emails that drive immediate purchases.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_5efc61-02","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_5efc61-02 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"home-chipi"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_1d7044-78","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_1d7044-78 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_1d7044-78">Intuitive waitlist management</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_99cdcc-94","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"mobileMargin":[8,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_99cdcc-94 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_99cdcc-94">Monitor product demand, track interested customers, and make smarter inventory decisions from one dashboard.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_074b57-cc","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_074b57-cc kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-chipi"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_4bff1d-ab","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_4bff1d-ab wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_4bff1d-ab">Abandonment prevention</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_4af8f0-24","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8.1,0,0,0],"tabletMargin":[8,"","",""],"mobileMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_4af8f0-24 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_4af8f0-24">Reduce cart abandonment by offering a notification option when items become unavailable during shopping.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_8603c3-4c","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv","anchor":"customize"} -->
<div class="wp-block-kadence-column kadence-column7_8603c3-4c kb-section-dir-vertical six rv" id="customize"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-chipi-2"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_c0ce53-fa","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_c0ce53-fa wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_c0ce53-fa">Fully customizable experience</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_0ba88f-40","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_0ba88f-40 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0ba88f-40">Tailor form headings, button text, colours, hover effects and email templates to match your store's branding.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_93be58-87","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_93be58-87 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"home-features-2"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_4dc161-23","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_4dc161-23 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_4dc161-23">Comprehensive analytics</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_7d7e64-2c","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_7d7e64-2c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_7d7e64-2c">Access stock logs, manage product lists, and export shop data to make inventory decisions based on real demand.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_41b6e6-f4","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"six rv"} -->
<div class="wp-block-kadence-column kadence-column7_41b6e6-f4 kb-section-dir-vertical six rv"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"home-features-5"} /-->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_490e40-77","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[18,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_490e40-77 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_490e40-77">reCAPTCHA central</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_0f241a-e6","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15.5,"",""],"sizeType":"px","fontHeight":[25.575,"",""],"fontHeightType":"px","fontWeight":"400","margin":[8,0,0,0],"mobileMargin":[8.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_0f241a-e6 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0f241a-e6">Keep only genuine subscribers, prevent spam, strengthen security and support compliance.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_da2978-c3","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[40,28,40,28],"tabletPadding":[40,28,40,28],"mobilePadding":[40,18,40,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dast-global-color-5)","columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec tint"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_16dff4-5c","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_16dff4-5c kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/rowlayout {"uniqueID":"7_81f260-4a","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"verticalAlignment":"middle","kbVersion":2,"className":"fz rv","anchor":"admin-alerts"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_f82157-ec","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_f82157-ec kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_64afda-8a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_64afda-8a wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_64afda-8a">Stay informed about product demand</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_24ed5a-5f","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"tabletMargin":[11.55,"","",""],"mobileMargin":[10.75,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_24ed5a-5f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_24ed5a-5f">Admin alerts</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_70fd6d-8e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"tabletMargin":[13.9,"","",""],"mobileMargin":[14,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_70fd6d-8e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_70fd6d-8e">Stay one step ahead with real-time notifications about customer demand for your out-of-stock products, so you can make smarter inventory decisions.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_128402-62","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22.1,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_128402-62 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_1c48ed-fd"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_1c48ed-fd"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Get an alert when customers join a product waitlist</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_fc6fe7-c7"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_fc6fe7-c7"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">See which out-of-stock items are requested most</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_9c82c3-03"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_9c82c3-03"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Prioritize restocking based on real customer demand</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_1eb0f0-53","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_1eb0f0-53 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-zz-art"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_e1cb58-a2","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"verticalAlignment":"middle","kbVersion":2,"className":"fz rev rv","anchor":"double-opt-in"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_c4db67-18","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_c4db67-18 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_b59089-72","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_b59089-72 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_b59089-72">Build trust and compliance</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_406d42-4a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"tabletMargin":[11.55,"","",""],"mobileMargin":[10.85,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_406d42-4a wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_406d42-4a">Double opt-in system</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_ecf38d-83","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"mobileMargin":[13.9,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_ecf38d-83 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_ecf38d-83">Create a trustworthy notification system that respects privacy regulations and customer preferences.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_701f26-90","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_701f26-90 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_420da5-9c"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_420da5-9c"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Email verification before the subscription is confirmed</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_41fcd9-2f"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_41fcd9-2f"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Compliance with regional email regulations</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_0ecb70-41"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_0ecb70-41"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Fewer accidental subscriptions</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_29d929-82"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_29d929-82"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Better overall email deliverability</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_2d4e4a-05","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_2d4e4a-05 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-zz-art-2"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_ef58d4-56","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"verticalAlignment":"middle","kbVersion":2,"className":"fz rv","anchor":"security"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_21929c-ba","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_21929c-ba kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_d65633-20","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_d65633-20 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_d65633-20">Keep your notification lists genuine</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_d72f9c-a4","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"tabletMargin":[11.55,"","",""],"mobileMargin":[10.75,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_d72f9c-a4 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_d72f9c-a4">Email security controls</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_4d485d-35","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"tabletMargin":[13.9,"","",""],"mobileMargin":[14,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_4d485d-35 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_4d485d-35">Maintain the integrity of your waitlist with filtering tools that make sure only genuine subscribers make the cut.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_084f3a-5f","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_084f3a-5f kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_d7cdfb-66"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_d7cdfb-66"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Block problematic email domains with one click</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_25eeba-05"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_25eeba-05"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Ban specific email addresses from your waitlists</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_78c743-3b"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_78c743-3b"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Custom error messages for rejected signups</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_4762fa-de"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_4762fa-de"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Whitelist priority customers and partners</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_9f2a01-ba","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_9f2a01-ba kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-zz-art-3"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_ace946-b1","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"verticalAlignment":"middle","kbVersion":2,"className":"fz rev rv","anchor":"unsubscribe"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_bca843-c7","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_bca843-c7 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_4e4910-42","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_4e4910-42 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_4e4910-42">Respect customer preferences automatically</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_e16d9e-19","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"mobileMargin":[10.75,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_e16d9e-19 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_e16d9e-19">Unsubscribe management</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_c8a926-3b","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_c8a926-3b wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_c8a926-3b">Give customers full control over their notifications with a self-service system that builds trust.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_bc9d24-a8","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_bc9d24-a8 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_aa5478-14"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_aa5478-14"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Unsubscribe right from the My Account dashboard</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_a05dfd-22"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_a05dfd-22"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Leave one product waitlist without leaving all alerts</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_0fbe57-cf"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_0fbe57-cf"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Preferences stay in sync across integrations</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_841a34-28"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_841a34-28"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Subscription history to review past choices</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_ae6a7b-e8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_ae6a7b-e8 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-zz-art-4"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_f829e8-0f","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"mobileMargin":[-0.1,"","",""],"inheritMaxWidth":true,"borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"verticalAlignment":"middle","kbVersion":2,"className":"fz rv","anchor":"recaptcha"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_25c174-b2","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_25c174-b2 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_8115d1-04","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_8115d1-04 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_8115d1-04">Quality over quantity</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_7af364-b2","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"mobileMargin":[10.85,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_7af364-b2 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_7af364-b2">reCAPTCHA protection</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_cc1e9d-2a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_cc1e9d-2a wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_cc1e9d-2a">Make sure your waitlists contain only genuine customers with Google reCAPTCHA verification.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_4dc324-39","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_4dc324-39 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_19bd5a-ce"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_19bd5a-ce"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Stops spam and bot subscriptions</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_2eed16-cd"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_2eed16-cd"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Keeps subscriber data high quality</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_4176ed-3a"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_4176ed-3a"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Adds security to your website</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_ecdf64-00"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_ecdf64-00"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Customizable reCAPTCHA appearance</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_45a7c8-ac","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_45a7c8-ac kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-zz-art-5"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_b2777a-ca","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"mobileMargin":[0.1,"","",""],"inheritMaxWidth":true,"borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"verticalAlignment":"middle","kbVersion":2,"className":"fz rev rv","anchor":"dashboard"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_c1c776-67","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_c1c776-67 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_09a258-f3","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_09a258-f3 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_09a258-f3">Customer control center</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_eb3099-92","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.45,0,0,0],"mobileMargin":[10.85,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_eb3099-92 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_eb3099-92">User subscription dashboard</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_928ccd-2b","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_928ccd-2b wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_928ccd-2b">Give customers a self-service portal where they manage their own waitlist preferences.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_1be6ad-74","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[22,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_1be6ad-74 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_dd8f07-a9"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_dd8f07-a9"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">A dashboard for every subscribed product</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_197bfd-37"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_197bfd-37"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">One-click unsubscribe options</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_fee75a-dc"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_fee75a-dc"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Subscription history and status tracking</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_9f1788-c5"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_9f1788-c5"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Notification frequency preferences</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_20709f-65","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_20709f-65 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-zz-art-6"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_5ab1bf-4f","columns":2,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[72,32,""],"collapseGutter":"custom","customRowGutter":[72,32,""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[56,0,56,0],"tabletPadding":[56,0,56,0],"mobilePadding":[56,0,56,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"verticalAlignment":"middle","kbVersion":2,"className":"fz rv","anchor":"mailchimp"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_c6fb52-d7","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_c6fb52-d7 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_4a1ddd-62","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","margin":[3.45,0,0,0],"mobileMargin":[2.45,"","",""],"marginType":"px","className":"eye"} -->
<span class="kt-adv-heading7_4a1ddd-62 wp-block-kadence-advancedheading eye" data-kb-block="kb-adv-heading7_4a1ddd-62">Supercharge your email marketing</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_a97c52-05","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[40,28,""],"sizeType":"px","fontHeight":[46,32.2,""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1,"tabletLetterSpacing":-0.7,"margin":[11.55,0,0,0],"tabletMargin":[11.45,"","",""],"mobileMargin":[10.85,"","",""],"marginType":"px"} -->
<h2 class="kt-adv-heading7_a97c52-05 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_a97c52-05">Mailchimp integration</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_c38374-09","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[17.5,"",""],"sizeType":"px","fontHeight":[28.875,"",""],"fontHeightType":"px","fontWeight":"400","margin":[14,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_c38374-09 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_c38374-09">Connect your waitlist to Mailchimp and turn every subscriber into part of your marketing reach.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[17,"",16],"sizeType":"px","lineHeight":[28.05,"",26.4],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":10,"uniqueID":"7_f872d6-30","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":10,"iconAlign":"top","listMargin":[21.9,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_f872d6-30 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_ede3ef-ec"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_ede3ef-ec"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Instant and batch synchronization</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_cae6b1-95"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_cae6b1-95"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Waitlist subscribers sync to Mailchimp automatically</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_bdd3be-2d"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_bdd3be-2d"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Segments based on product interest</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_cf177c-0e"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_cf177c-0e"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Use Mailchimp's advanced email features</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_a35f2e-5f","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_a35f2e-5f kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-zz-art-7"} /--></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_047473-8b","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_be28d4-9a","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_be28d4-9a kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_c38e2e-f3","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_c38e2e-f3 kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_bf58b7-2e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.5,0,0,0],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_bf58b7-2e wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_bf58b7-2e">Pricing</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_ba927e-01","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_ba927e-01 wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_ba927e-01">Pricing plans designed for <mark class="kt-highlight">growth</mark></h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_6f629b-f3","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[16,0,0,0],"marginType":"px","className":"intro"} -->
<p class="kt-adv-heading7_6f629b-f3 wp-block-kadence-advancedheading intro" data-kb-block="kb-adv-heading7_6f629b-f3">Transform inventory gaps into sales opportunities automatically.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_5242d3-04","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[56,0,0,0],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_5242d3-04 kb-section-dir-vertical"><div class="kt-inside-inner-col">{{ref:section-price-shell}}</div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_5d5793-31","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[28,0,0,0],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_5d5793-31 kb-section-dir-vertical"><div class="kt-inside-inner-col">{{ref:section-trust}}</div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_4f6326-5a","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[44,0,0,0],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_4f6326-5a kb-section-dir-vertical"><div class="kt-inside-inner-col">{{ref:section-tcards}}</div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_3391c3-f1","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[104,28,104,28],"tabletPadding":[76,28,76,28],"mobilePadding":[76,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dast-global-color-5)","columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k sec tint"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_274736-d5","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_274736-d5 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_0b256f-03","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"center rv"} -->
<div class="wp-block-kadence-column kadence-column7_0b256f-03 kb-section-dir-vertical center rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_17eea6-44","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":0.14,"margin":[7.4,0,0,0],"mobileMargin":[6.4,"","",""],"marginType":"px","className":"kicker"} -->
<span class="kt-adv-heading7_17eea6-44 wp-block-kadence-advancedheading kicker" data-kb-block="kb-adv-heading7_17eea6-44">FAQ</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_d2b261-25","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[50,32.8,32],"sizeType":"px","fontHeight":[57.5,37.72,36.8],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.25,"tabletLetterSpacing":-0.82,"mobileLetterSpacing":-0.8,"margin":[14,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)","className":"title"} -->
<h2 class="kt-adv-heading7_d2b261-25 wp-block-kadence-advancedheading title" data-kb-block="kb-adv-heading7_d2b261-25">Feature <mark class="kt-highlight">questions</mark></h2>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_9570ad-b5","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"borderStyle":[{"top":["var(\u002d\u002dast-global-color-7)","solid",1],"right":["","",""],"bottom":["","",""],"left":["","",""],"unit":"px"}],"margin":[48,0,0,0],"tabletMargin":[47.9,"","",""],"mobileMargin":[48,"","",""],"kbVersion":2,"className":"faq"} -->
<div class="wp-block-kadence-column kadence-column7_9570ad-b5 kb-section-dir-vertical faq"><div class="kt-inside-inner-col"><!-- wp:notifima/graphic {"name":"features-qa"} /-->

<!-- wp:notifima/graphic {"name":"features-qa-2"} /-->

<!-- wp:notifima/graphic {"name":"features-qa-3"} /-->

<!-- wp:notifima/graphic {"name":"features-qa-4"} /-->

<!-- wp:notifima/graphic {"name":"features-qa-5"} /--></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
