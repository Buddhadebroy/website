<?php
/**
 * Notifima Astra Child theme bootstrap.
 *
 * Loads theme modules in dependency order. Keep this file limited to
 * constants and module loading.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;

define( 'NF_VERSION', '2.3.9' );
define( 'NF_DIR', get_stylesheet_directory() );
define( 'NF_URI', get_stylesheet_directory_uri() );

// Core helpers and site configuration.
$nf_files = array(
	'inc/helpers.php',
	'inc/customizer.php',
	'inc/root-vars.php',
	'inc/setup.php',

	// Editor content: synced patterns, custom blocks and graphics.
	'inc/patterns.php',
	'inc/header-footer.php',
	'inc/blocks.php',
	'graphic/graphic.php',

	// Website features and integrations.
	'inc/releases.php',
	'inc/woocommerce.php',
	'inc/docs.php',
	'inc/release-pro.php',

	// Theme administration.
	'inc/admin.php',
);

$nf_missing = array();

foreach ( $nf_files as $nf_file ) {
	$nf_path = NF_DIR . '/' . $nf_file;

	if ( is_readable( $nf_path ) ) {
		require_once $nf_path;
	} else {
		$nf_missing[] = $nf_file;
	}
}

if ( $nf_missing ) {
	add_action(
		'admin_notices',
		function () use ( $nf_missing ) {
			if ( ! current_user_can( 'switch_themes' ) ) {
				return;
			}

			echo '<div class="notice notice-error"><p><strong>Notifima theme:</strong> ';
			echo esc_html__( 'Some theme files are missing. Upload the complete theme ZIP again.', 'notifima' );
			echo ' <code>' . esc_html( implode( ', ', $nf_missing ) ) . '</code></p></div>';
		}
	);
}
