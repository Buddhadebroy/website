<?php
/**
 * Title: Shared · trust
 * Slug: notifima/section-trust
 * Categories: notifima
 * Keywords: notifima, kadence, shared
 * Viewport Width: 1440
 * Description: Used on: features, home, pricing.
 *
 * Kadence blocks whose own settings carry the design (Row Layout, Section, Advanced Text, Icon List, Buttons)
 * + the theme blocks (Animated Graphic, Site Logo, Site Menu). Production Kadence block markup used to create the editable synced pattern.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_c558d9-61","columns":1,"colLayout":"equal","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[0,"",0,""],"inheritMaxWidth":false,"columnGutter":"none","kbVersion":2,"className":"nf-k nf-shared"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_8e2476-6e","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_8e2476-6e kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_7acd53-a2","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","color":"var(\u002d\u002dast-global-color-3)","fontSize":[15,"",""],"sizeType":"px","fontHeight":[24.75,"",""],"fontHeightType":"px","fontWeight":"400","margin":[0,0,0,0],"marginType":"px","className":"trust rv"} -->
<div class="kt-adv-heading7_7acd53-a2 wp-block-kadence-advancedheading trust rv" data-kb-block="kb-adv-heading7_7acd53-a2"><span><svg aria-hidden="true" class="i"><use href="#shield"></use></svg>15-day money back guarantee</span><span><svg aria-hidden="true" class="i"><use href="#lock"></use></svg>Secure checkout</span><span><svg aria-hidden="true" class="i"><use href="#help"></use></svg>Priority support</span><span><svg aria-hidden="true" class="i"><use href="#refresh"></use></svg>1 year of updates</span></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
