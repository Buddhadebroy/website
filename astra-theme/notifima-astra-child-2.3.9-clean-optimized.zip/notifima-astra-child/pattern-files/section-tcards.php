<?php
/**
 * Title: Shared · Money back guarantee
 * Slug: notifima/section-tcards
 * Categories: notifima
 * Keywords: notifima, kadence, shared
 * Viewport Width: 1440
 * Description: Used on: features, pricing.
 *
 * Kadence blocks whose own settings carry the design (Row Layout, Section, Advanced Text, Icon List, Buttons)
 * + the theme blocks (Animated Graphic, Site Logo, Site Menu). Production Kadence block markup used to create the editable synced pattern.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_b0a2d2-97","columns":3,"colLayout":"equal","tabletLayout":"two-grid","mobileLayout":"row","columnGutter":"custom","customGutter":[20,"",""],"collapseGutter":"custom","customRowGutter":[20,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnsInnerHeight":true,"kbVersion":2,"className":"tcards"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_5dea82-2b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"tcard rv"} -->
<div class="wp-block-kadence-column kadence-column7_5dea82-2b kb-section-dir-vertical tcard rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_ce5241-6e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[0,0,0,0],"marginType":"px","background":"var(\u002d\u002dp-50)","borderRadius":[50,50,50,50],"borderRadiusUnit":"%","className":"seal"} -->
<div class="kt-adv-heading7_ce5241-6e wp-block-kadence-advancedheading seal" data-kb-block="kb-adv-heading7_ce5241-6e"><b>15</b></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_1a893c-11","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[16,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_1a893c-11 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_1a893c-11">Money back guarantee</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_18b9b6-70","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[15,"",""],"sizeType":"px","fontHeight":[24.75,"",""],"fontHeightType":"px","fontWeight":"400","margin":[6,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_18b9b6-70 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_18b9b6-70">Risk-free for 15 days. If Notifima doesn't fully meet your expectations, we'll process your refund. <a href="#nf-refund">Refund Policy</a></p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_a54645-60","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"tcard rv"} -->
<div class="wp-block-kadence-column kadence-column7_a54645-60 kb-section-dir-vertical tcard rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_c98833-2a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[0,0,0,0],"marginType":"px","background":"var(\u002d\u002dp-50)","borderRadius":[50,50,50,50],"borderRadiusUnit":"%","className":"seal"} -->
<div class="kt-adv-heading7_c98833-2a wp-block-kadence-advancedheading seal" data-kb-block="kb-adv-heading7_c98833-2a"><svg aria-hidden="true" class="i"><use href="#lock"></use></svg></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_3f512c-7f","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[16,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_3f512c-7f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_3f512c-7f">Data security</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_f2f86f-58","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[15,"",""],"sizeType":"px","fontHeight":[24.75,"",""],"fontHeightType":"px","fontWeight":"400","margin":[6,0,0,0],"marginType":"px"} -->
<p class="kt-adv-heading7_f2f86f-58 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_f2f86f-58">Your data is secured with 256-bit SSL/TLS encryption to keep it protected.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_da2e22-dd","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[28,28,28,28],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[24,24,24,24],"kbVersion":2,"className":"tcard rv"} -->
<div class="wp-block-kadence-column kadence-column7_da2e22-dd kb-section-dir-vertical tcard rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_d98e5b-50","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dast-global-color-0)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[0,0,0,0],"marginType":"px","background":"var(\u002d\u002dp-50)","borderRadius":[50,50,50,50],"borderRadiusUnit":"%","className":"seal"} -->
<div class="kt-adv-heading7_d98e5b-50 wp-block-kadence-advancedheading seal" data-kb-block="kb-adv-heading7_d98e5b-50"><svg aria-hidden="true" class="i"><use href="#card"></use></svg></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_12d09e-4b","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[16,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_12d09e-4b wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_12d09e-4b">Accepted payment methods</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_a8005f-37","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dmut)","fontSize":[15,"",""],"sizeType":"px","fontHeight":[24.75,"",""],"fontHeightType":"px","fontWeight":"400","margin":[6,0,0,0],"mobileMargin":[6.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_a8005f-37 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_a8005f-37">Pay securely via Stripe, PayPal or credit card.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_88f05d-94","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[12,0,0,0],"marginType":"px","className":"pays"} -->
<div class="kt-adv-heading7_88f05d-94 wp-block-kadence-advancedheading pays" data-kb-block="kb-adv-heading7_88f05d-94"><span>Stripe</span><span>PayPal</span><span>Visa</span><span>Mastercard</span><span>Amex</span></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
