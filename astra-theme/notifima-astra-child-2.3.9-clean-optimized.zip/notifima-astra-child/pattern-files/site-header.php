<?php
/**
 * Title: Site · Header
 * Slug: notifima/site-header
 * Categories: notifima
 * Keywords: notifima, header
 * Viewport Width: 1440
 * Description: Logo, menu with the Resources mega menu, cart/account icons, Contact Sales button, phone menu.
 *
 * Kadence blocks whose own settings carry the design (Row Layout, Section, Advanced Text, Icon List, Buttons)
 * + the theme blocks (Animated Graphic, Site Logo, Site Menu). Production Kadence block markup used to create the editable synced pattern.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_e2c28b-5c","htmlTag":"header","columns":1,"colLayout":"equal","align":"full","inheritMaxWidth":true,"padding":[0,0,0,0],"kbVersion":2,"className":"nf-k hdr","anchor":"top"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_c060ff-c9","kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-column7_c060ff-c9 wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_d80953-3c","kbVersion":2,"className":"hdr-bar"} -->
<div class="wp-block-kadence-column kadence-column7_d80953-3c hdr-bar"><div class="kt-inside-inner-col"><!-- wp:notifima/site-logo /-->

<!-- wp:notifima/site-menu /-->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_889165-df","kbVersion":2,"className":"hdr-act"} -->
<div class="wp-block-kadence-column kadence-column7_889165-df hdr-act"><div class="kt-inside-inner-col"><!-- wp:notifima/site-menu {"part":"icons"} /-->

<!-- wp:kadence/advancedbtn {"hAlign":"left","uniqueID":"7_7f24d5-5f","className":"nf-hdr-cta"} -->
<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns7_7f24d5-5f nf-hdr-cta"><!-- wp:kadence/singlebtn {"uniqueID":"7_a2c799-f2","text":"Contact Sales","link":"#nf-contact","className":"btn btn-p btn-sm"} /--></div>
<!-- /wp:kadence/advancedbtn -->

<!-- wp:notifima/site-menu {"part":"toggle"} /--></div></div>
<!-- /wp:kadence/column -->

<!-- wp:notifima/site-menu {"part":"drawer"} /--></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
