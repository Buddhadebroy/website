<?php
/**
 * Title: Shared · Individual
 * Slug: notifima/section-price-shell
 * Categories: notifima
 * Keywords: notifima, kadence, shared
 * Viewport Width: 1440
 * Description: Used on: features, home, pricing.
 *
 * Kadence blocks whose own settings carry the design (Row Layout, Section, Advanced Text, Icon List, Buttons)
 * + the theme blocks (Animated Graphic, Site Logo, Site Menu). Production Kadence block markup used to create the editable synced pattern.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_55c439-19","columns":1,"colLayout":"equal","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[0,"",0,""],"inheritMaxWidth":false,"columnGutter":"none","kbVersion":2,"className":"nf-k nf-shared"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_cb62a1-13","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[12,12,12,12],"background":"var(\u002d\u002dast-global-color-4)","borderStyle":[{"top":["var(\u002d\u002dline-2)","solid",1],"right":["var(\u002d\u002dline-2)","solid",1],"bottom":["var(\u002d\u002dline-2)","solid",1],"left":["var(\u002d\u002dline-2)","solid",1],"unit":"px"}],"borderRadius":[32,32,32,32],"kbVersion":2,"className":"price-shell rv"} -->
<div class="wp-block-kadence-column kadence-column7_cb62a1-13 kb-section-dir-vertical price-shell rv"><div class="kt-inside-inner-col"><!-- wp:kadence/rowlayout {"uniqueID":"7_d78879-67","columns":3,"colLayout":"equal","tabletLayout":"row","columnGutter":"custom","customGutter":[12,"",""],"collapseGutter":"custom","customRowGutter":[12,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[0,0,0,0],"tabletPadding":[0,0,0,0],"mobilePadding":[0,0,0,0],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnsInnerHeight":true,"kbVersion":2,"className":"plans"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_4e718d-90","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[30,28,30,28],"mobilePadding":[26,20,26,20],"background":"var(\u002d\u002dast-global-color-4)","borderRadius":[24,24,24,24],"kbVersion":2,"className":"plan"} -->
<div class="wp-block-kadence-column kadence-column7_4e718d-90 kb-section-dir-vertical plan"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_54f8d3-7b","direction":["horizontal","",""],"gutter":[14,"",""],"gutterVariable":["custom","",""],"justifyContent":["flex-start","",""],"verticalAlignment":"middle","wrapContent":["nowrap","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"pl-top"} -->
<div class="wp-block-kadence-column kadence-column7_54f8d3-7b kb-section-dir-horizontal pl-top"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_66581a-8f","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[0,0,0,0],"marginType":"px","background":"var(\u002d\u002dast-global-color-5)","borderRadius":[14,14,14,14],"className":"pl-ico"} -->
<span class="kt-adv-heading7_66581a-8f wp-block-kadence-advancedheading pl-ico" data-kb-block="kb-adv-heading7_66581a-8f"><svg aria-hidden="true" class="i"><use href="#user"></use></svg></span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_b94b74-f7","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_b94b74-f7 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_562d3d-39","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[22,"",""],"sizeType":"px","fontHeight":[25.3,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.33,"margin":[0,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_562d3d-39 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_562d3d-39">Individual</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_be829f-15","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15,"",""],"sizeType":"px","fontHeight":[21,"",""],"fontHeightType":"px","fontWeight":"400","margin":[2,0,0,0],"marginType":"px","className":"for"} -->
<p class="kt-adv-heading7_be829f-15 wp-block-kadence-advancedheading for" data-kb-block="kb-adv-heading7_be829f-15">For individual online store owners</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_cd073d-3e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","color":"var(\u002d\u002dast-global-color-2)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[28,0,0,0],"marginType":"px","className":"price"} -->
<div class="kt-adv-heading7_cd073d-3e wp-block-kadence-advancedheading price" data-kb-block="kb-adv-heading7_cd073d-3e"><sup>$</sup><strong>49</strong><span>/ year</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_29f1f8-03","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[14.5,"",""],"sizeType":"px","fontHeight":[23.925,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"marginType":"px","className":"per"} -->
<p class="kt-adv-heading7_29f1f8-03 wp-block-kadence-advancedheading per" data-kb-block="kb-adv-heading7_29f1f8-03"><b>$49</b> per site, per year</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedbtn {"uniqueID":"7_25fb0e-c9","hAlign":"left","margin":[{"desk":[22,0,0,0],"tablet":["","","",""],"mobile":["","","",""]}]} -->
<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns7_25fb0e-c9"><!-- wp:kadence/singlebtn {"uniqueID":"7_0dc2c9-40","text":"Get Individual","link":"#nf-buy_individual","icon":"fe_arrowRight","typography":[{"size":[16,"",""],"sizeType":"px","lineHeight":[26.4,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"500","variant":"","subset":"","loadGoogle":true,"textTransform":""}],"color":"var(\u002d\u002dast-global-color-2)","background":"var(\u002d\u002dast-global-color-4)","colorHover":"var(\u002d\u002dast-global-color-2)","backgroundHover":"var(\u002d\u002dast-global-color-4)","padding":[11.8,26,11.8,26],"paddingUnit":"px","borderRadius":[999,999,999,999],"borderStyle":[{"top":["var(\u002d\u002dast-global-color-7)","solid",1],"right":["var(\u002d\u002dast-global-color-7)","solid",1],"bottom":["var(\u002d\u002dast-global-color-7)","solid",1],"left":["var(\u002d\u002dast-global-color-7)","solid",1],"unit":"px"}],"borderHoverStyle":[{"top":["var(\u002d\u002dast-global-color-2)","solid",1],"right":["var(\u002d\u002dast-global-color-2)","solid",1],"bottom":["var(\u002d\u002dast-global-color-2)","solid",1],"left":["var(\u002d\u002dast-global-color-2)","solid",1],"unit":"px"}],"className":"btn btn-g"} /--></div>
<!-- /wp:kadence/advancedbtn -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[15.5,"",""],"sizeType":"px","lineHeight":[25.575,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-3)","textTransform":""}],"listGap":11.9,"uniqueID":"7_e0e26b-3d","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":11,"iconAlign":"middle","listMargin":[26,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_e0e26b-3d kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_52d34a-96","icon":"fe_globe"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_52d34a-96"><span data-name="fe_globe" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Use on 1 site</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_d67fd9-51"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_d67fd9-51"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">All Pro add-ons and features</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_401432-df"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_401432-df"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Priority support</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_b79840-c1"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_b79840-c1"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Updates for 1 year</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_80d614-ac","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[30,28,30,28],"mobilePadding":[26,20,26,20],"borderRadius":[24,24,24,24],"displayShadow":true,"shadow":[{"color":"#d6b8ff","opacity":1,"spread":1.5,"blur":0,"hOffset":0,"vOffset":0,"inset":true}],"kbVersion":2,"className":"plan pop"} -->
<div class="wp-block-kadence-column kadence-column7_80d614-ac kb-section-dir-vertical plan pop"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_fe07d5-4d","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[13,"",""],"sizeType":"px","fontHeight":[21.45,"",""],"fontHeightType":"px","fontWeight":"500","padding":[4,12,4,12],"margin":[0,0,0,0],"marginType":"px","background":"var(\u002d\u002dast-global-color-4)","borderRadius":[999,999,999,999],"borderStyle":[{"top":["var(\u002d\u002dp-200)","solid",1],"right":["var(\u002d\u002dp-200)","solid",1],"bottom":["var(\u002d\u002dp-200)","solid",1],"left":["var(\u002d\u002dp-200)","solid",1],"unit":"px"}],"className":"ribbon"} -->
<span class="kt-adv-heading7_fe07d5-4d wp-block-kadence-advancedheading ribbon" data-kb-block="kb-adv-heading7_fe07d5-4d"><svg aria-hidden="true" class="i"><use href="#star"></use></svg> Most popular</span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_7f6204-5c","direction":["horizontal","",""],"gutter":[14,"",""],"gutterVariable":["custom","",""],"justifyContent":["flex-start","",""],"verticalAlignment":"middle","wrapContent":["nowrap","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"pl-top"} -->
<div class="wp-block-kadence-column kadence-column7_7f6204-5c kb-section-dir-horizontal pl-top"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_086ff7-44","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-4)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[0,0,0,0],"marginType":"px","background":"var(\u002d\u002dast-global-color-0)","borderRadius":[14,14,14,14],"className":"pl-ico"} -->
<span class="kt-adv-heading7_086ff7-44 wp-block-kadence-advancedheading pl-ico" data-kb-block="kb-adv-heading7_086ff7-44"><svg aria-hidden="true" class="i"><use href="#users"></use></svg></span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_07024a-63","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_07024a-63 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_8265b0-33","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[22,"",""],"sizeType":"px","fontHeight":[25.3,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.33,"margin":[0,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_8265b0-33 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_8265b0-33">Business</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_a27ff9-2e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15,"",""],"sizeType":"px","fontHeight":[21,"",""],"fontHeightType":"px","fontWeight":"400","margin":[2,0,0,0],"marginType":"px","className":"for"} -->
<p class="kt-adv-heading7_a27ff9-2e wp-block-kadence-advancedheading for" data-kb-block="kb-adv-heading7_a27ff9-2e">For solo freelancers and experts</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_37892c-f8","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","color":"var(\u002d\u002dast-global-color-2)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[28,0,0,0],"marginType":"px","className":"price"} -->
<div class="kt-adv-heading7_37892c-f8 wp-block-kadence-advancedheading price" data-kb-block="kb-adv-heading7_37892c-f8"><sup>$</sup><strong>69</strong><span>/ year</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_ba4b6a-cc","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[14.5,"",""],"sizeType":"px","fontHeight":[23.925,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"marginType":"px","className":"per"} -->
<p class="kt-adv-heading7_ba4b6a-cc wp-block-kadence-advancedheading per" data-kb-block="kb-adv-heading7_ba4b6a-cc"><b>$23</b> per site, per year</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedbtn {"uniqueID":"7_236fd6-f3","hAlign":"left","margin":[{"desk":[22,0,0,0],"tablet":["","","",""],"mobile":["","","",""]}]} -->
<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns7_236fd6-f3"><!-- wp:kadence/singlebtn {"uniqueID":"7_5d3fc8-1c","text":"Get Business","link":"#nf-buy_business","icon":"fe_arrowRight","typography":[{"size":[16,"",""],"sizeType":"px","lineHeight":[26.4,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"500","variant":"","subset":"","loadGoogle":true,"textTransform":""}],"color":"var(\u002d\u002dast-global-color-4)","background":"var(\u002d\u002dast-global-color-0)","colorHover":"var(\u002d\u002dast-global-color-4)","backgroundHover":"var(\u002d\u002dp-d)","padding":[11.8,26,11.8,26],"paddingUnit":"px","borderRadius":[999,999,999,999],"borderStyle":[{"top":["","solid",1],"right":["","solid",1],"bottom":["","solid",1],"left":["","solid",1],"unit":"px"}],"borderHoverStyle":[{"top":["","solid",1],"right":["","solid",1],"bottom":["","solid",1],"left":["","solid",1],"unit":"px"}],"displayShadow":true,"shadow":[{"color":"#852aff","opacity":0.8,"spread":-10,"blur":24,"hOffset":0,"vOffset":10,"inset":false}],"className":"btn btn-p"} /--></div>
<!-- /wp:kadence/advancedbtn -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[15.5,"",""],"sizeType":"px","lineHeight":[25.575,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-3)","textTransform":""}],"listGap":11.9,"uniqueID":"7_7e01f0-34","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":11,"iconAlign":"middle","listMargin":[26,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_7e01f0-34 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_d3746c-32","icon":"fe_globe"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_d3746c-32"><span data-name="fe_globe" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Use on 3 sites</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_9af4f5-87"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_9af4f5-87"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">All Pro add-ons and features</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_038639-a6"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_038639-a6"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Priority support</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_9deeb7-f2"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_9deeb7-f2"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Updates for 1 year</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_a468b4-01","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"padding":[30,28,30,28],"mobilePadding":[26,20,26,20],"background":"var(\u002d\u002dast-global-color-4)","borderRadius":[24,24,24,24],"kbVersion":2,"className":"plan"} -->
<div class="wp-block-kadence-column kadence-column7_a468b4-01 kb-section-dir-vertical plan"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_a8e68d-b7","direction":["horizontal","",""],"gutter":[14,"",""],"gutterVariable":["custom","",""],"justifyContent":["flex-start","",""],"verticalAlignment":"middle","wrapContent":["nowrap","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"margin":[0,0,0,0],"kbVersion":2,"className":"pl-top"} -->
<div class="wp-block-kadence-column kadence-column7_a8e68d-b7 kb-section-dir-horizontal pl-top"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_aca81b-d2","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"span","color":"var(\u002d\u002dast-global-color-0)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[0,0,0,0],"marginType":"px","background":"var(\u002d\u002dast-global-color-5)","borderRadius":[14,14,14,14],"className":"pl-ico"} -->
<span class="kt-adv-heading7_aca81b-d2 wp-block-kadence-advancedheading pl-ico" data-kb-block="kb-adv-heading7_aca81b-d2"><svg aria-hidden="true" class="i"><use href="#building"></use></svg></span>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_6a4e94-6b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_6a4e94-6b kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"level":3,"uniqueID":"7_7224b4-20","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[22,"",""],"sizeType":"px","fontHeight":[25.3,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.33,"margin":[0,0,0,0],"marginType":"px"} -->
<h3 class="kt-adv-heading7_7224b4-20 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_7224b4-20">Agency</h3>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_14ebda-5d","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[15,"",""],"sizeType":"px","fontHeight":[21,"",""],"fontHeightType":"px","fontWeight":"400","margin":[2,0,0,0],"mobileMargin":[1.9,"","",""],"marginType":"px","className":"for"} -->
<p class="kt-adv-heading7_14ebda-5d wp-block-kadence-advancedheading for" data-kb-block="kb-adv-heading7_14ebda-5d">For agencies with multiple projects</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_8ebabc-7a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","color":"var(\u002d\u002dast-global-color-2)","fontSize":[17,"",16],"sizeType":"px","fontHeight":[28.05,"",26.4],"fontHeightType":"px","fontWeight":"400","margin":[28,0,0,0],"mobileMargin":[27.9,"","",""],"marginType":"px","className":"price"} -->
<div class="kt-adv-heading7_8ebabc-7a wp-block-kadence-advancedheading price" data-kb-block="kb-adv-heading7_8ebabc-7a"><sup>$</sup><strong>99</strong><span>/ year</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_aa00e8-0e","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[14.5,"",""],"sizeType":"px","fontHeight":[23.925,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"marginType":"px","className":"per"} -->
<p class="kt-adv-heading7_aa00e8-0e wp-block-kadence-advancedheading per" data-kb-block="kb-adv-heading7_aa00e8-0e"><b>$9.90</b> per site, per year</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedbtn {"uniqueID":"7_b0a84b-44","hAlign":"left","margin":[{"desk":[22,0,0,0],"tablet":["","","",""],"mobile":[22.1,"","",""]}]} -->
<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns7_b0a84b-44"><!-- wp:kadence/singlebtn {"uniqueID":"7_2537da-7e","text":"Get Agency","link":"#nf-buy_agency","icon":"fe_arrowRight","typography":[{"size":[16,"",""],"sizeType":"px","lineHeight":[26.4,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"500","variant":"","subset":"","loadGoogle":true,"textTransform":""}],"color":"var(\u002d\u002dast-global-color-2)","background":"var(\u002d\u002dast-global-color-4)","colorHover":"var(\u002d\u002dast-global-color-2)","backgroundHover":"var(\u002d\u002dast-global-color-4)","padding":[11.8,26,11.8,26],"paddingUnit":"px","borderRadius":[999,999,999,999],"borderStyle":[{"top":["var(\u002d\u002dast-global-color-7)","solid",1],"right":["var(\u002d\u002dast-global-color-7)","solid",1],"bottom":["var(\u002d\u002dast-global-color-7)","solid",1],"left":["var(\u002d\u002dast-global-color-7)","solid",1],"unit":"px"}],"borderHoverStyle":[{"top":["var(\u002d\u002dast-global-color-2)","solid",1],"right":["var(\u002d\u002dast-global-color-2)","solid",1],"bottom":["var(\u002d\u002dast-global-color-2)","solid",1],"left":["var(\u002d\u002dast-global-color-2)","solid",1],"unit":"px"}],"className":"btn btn-g"} /--></div>
<!-- /wp:kadence/advancedbtn -->

<!-- wp:kadence/iconlist {"listStyles":[{"size":[15.5,"",""],"sizeType":"px","lineHeight":[25.575,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-3)","textTransform":""}],"listGap":11.9,"uniqueID":"7_4b2dfc-00","icon":"fe_check","color":"var(\u002d\u002dok-d)","iconSize":[20,"",""],"iconSpacing":11,"iconAlign":"middle","listMargin":[26,0,0,0]} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_4b2dfc-00 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_e07b3c-0a","icon":"fe_globe"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_e07b3c-0a"><span data-name="fe_globe" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Use on 10 sites</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_c43c81-0f"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_c43c81-0f"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">All Pro add-ons and features</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_549e01-3b"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_549e01-3b"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Priority support</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_ddbf82-47"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_ddbf82-47"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Updates for 1 year</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"7_41e30d-b7","columns":2,"colLayout":"equal","columnsUnlocked":true,"firstColumnWidth":24.864,"secondColumnWidth":75.136,"tabletLayout":"row","columnGutter":"custom","customGutter":[28,"",""],"collapseGutter":"custom","customRowGutter":[28,"",""],"tabletRowGutter":"custom","mobileRowGutter":"custom","padding":[26,28,26,28],"tabletPadding":[26,28,26,28],"mobilePadding":[26,28,26,28],"margin":[11.9,"",0,""],"tabletMargin":[12,"","",""],"inheritMaxWidth":true,"bgColor":"var(\u002d\u002dast-global-color-5)","borderRadius":[24,24,24,24],"verticalAlignment":"middle","kbVersion":2,"className":"incl"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_e19834-01","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_e19834-01 kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"level":4,"uniqueID":"7_72a026-26","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"color":"var(\u002d\u002dast-global-color-2)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[21.85,"",""],"fontHeightType":"px","fontWeight":"500","letterSpacing":-0.475,"margin":[0,0,0,0],"marginType":"px"} -->
<h4 class="kt-adv-heading7_72a026-26 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_72a026-26">Every plan includes</h4>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_20c0f7-dd","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","color":"var(\u002d\u002dmut)","fontSize":[14.5,"",""],"sizeType":"px","fontHeight":[23.925,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4.1,0,0,0],"tabletMargin":[4,"","",""],"mobileMargin":[4.1,"","",""],"marginType":"px"} -->
<p class="kt-adv-heading7_20c0f7-dd wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_20c0f7-dd">All Pro features. Plans differ only by the number of sites.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_527c21-fd","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2} -->
<div class="wp-block-kadence-column kadence-column7_527c21-fd kb-section-dir-vertical"><div class="kt-inside-inner-col"><!-- wp:kadence/iconlist {"listStyles":[{"size":[15,"",""],"sizeType":"px","lineHeight":[24.75,"",""],"lineType":"px","letterSpacing":"","family":"","google":false,"style":"","weight":"400","variant":"","subset":"","loadGoogle":true,"color":"var(\u002d\u002dast-global-color-2)","textTransform":""}],"listGap":11.9,"uniqueID":"7_23f6f0-1b","icon":"fe_bell","color":"var(\u002d\u002dast-global-color-0)","iconSize":[18,"",""],"iconSpacing":9,"iconAlign":"middle","listMargin":[0,0,0,0],"columns":3,"columnGap":20} -->
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items7_23f6f0-1b kt-svg-icon-list-columns-3 alignnone"><ul class="kt-svg-icon-list"><!-- wp:kadence/listitem {"uniqueID":"7_5e6c04-b9"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_5e6c04-b9"><span data-name="USE_PARENT_DEFAULT_ICON" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Back in stock emails</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_a2a3a8-b3","icon":"fe_layers"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_a2a3a8-b3"><span data-name="fe_layers" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Variable product alerts</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_898df9-60","icon":"fe_barChart2"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_898df9-60"><span data-name="fe_barChart2" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Demand tracking</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_8b0ffa-39","icon":"fe_checkCircle"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_8b0ffa-39"><span data-name="fe_checkCircle" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Double opt-in</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_c3e2b6-9c","icon":"fe_shield"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_c3e2b6-9c"><span data-name="fe_shield" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Spam and reCAPTCHA</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_566f18-6a","icon":"fe_send"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_566f18-6a"><span data-name="fe_send" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Mailchimp sync</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_3d4991-38","icon":"fe_globe"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_3d4991-38"><span data-name="fe_globe" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Multi-language</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_66ecff-af","icon":"fe_download"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_66ecff-af"><span data-name="fe_download" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">CSV export</span></li>
<!-- /wp:kadence/listitem -->

<!-- wp:kadence/listitem {"uniqueID":"7_1d998b-fc","icon":"fe_layout"} -->
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-7_1d998b-fc"><span data-name="fe_layout" data-stroke="USE_PARENT_DEFAULT_WIDTH" data-class="kt-svg-icon-list-single" class="kadence-dynamic-icon"></span><span class="kt-svg-icon-list-text">Subscriber dashboard</span></li>
<!-- /wp:kadence/listitem --></ul></div>
<!-- /wp:kadence/iconlist --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
