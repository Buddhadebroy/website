<?php
/**
 * Title: Site · Mega menu · Resources
 * Slug: notifima/mega-resources
 * Categories: notifima
 * Keywords: notifima, menu, mega
 * Viewport Width: 1440
 * Description: The Resources mega menu of the header. Edit text and links here; icon = Advanced → Additional CSS class nfi-NAME.
 *
 * Kadence blocks whose own settings carry the design (Row Layout, Section, Advanced Text, Icon List, Buttons)
 * + the theme blocks (Animated Graphic, Site Logo, Site Menu). Production Kadence block markup used to create the editable synced pattern.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_62f530-72","kbVersion":2,"className":"mega-in"} -->
<div class="wp-block-kadence-column kadence-column7_62f530-72 mega-in"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_dc6d82-73","kbVersion":2,"className":"mg-feat"} -->
<div class="wp-block-kadence-column kadence-column7_dc6d82-73 mg-feat"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_677581-fb","kbVersion":2,"className":"mg-mini"} -->
<div class="wp-block-kadence-column kadence-column7_677581-fb mg-mini"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_1c6720-c7","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"row nfi-file"} -->
<div class="kt-adv-heading7_1c6720-c7 wp-block-kadence-advancedheading row nfi-file" data-kb-block="kb-adv-heading7_1c6720-c7">[nf_latest field="short"]</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_2ce543-fe","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"row nfi-clock"} -->
<div class="kt-adv-heading7_2ce543-fe wp-block-kadence-advancedheading row nfi-clock" data-kb-block="kb-adv-heading7_2ce543-fe">[nf_latest field="read"]</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_cbb847-74","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"mg-ft"} -->
<div class="kt-adv-heading7_cbb847-74 wp-block-kadence-advancedheading mg-ft" data-kb-block="kb-adv-heading7_cbb847-74">[nf_latest field="title"]</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_764ac0-3a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","className":"mg-fp"} -->
<p class="kt-adv-heading7_764ac0-3a wp-block-kadence-advancedheading mg-fp" data-kb-block="kb-adv-heading7_764ac0-3a">Our most-read guide this month.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_52b7c8-c4","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"link nfa"} -->
<div class="kt-adv-heading7_52b7c8-c4 wp-block-kadence-advancedheading link nfa" data-kb-block="kb-adv-heading7_52b7c8-c4"><a href="#nf-latest">Read the post</a></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_e4cf22-32","kbVersion":2,"className":"mg-cols three"} -->
<div class="wp-block-kadence-column kadence-column7_e4cf22-32 mg-cols three"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_36b686-9d","kbVersion":2,"className":"mg-group"} -->
<div class="wp-block-kadence-column kadence-column7_36b686-9d mg-group"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"level":6,"uniqueID":"7_0c4d1d-2c","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}]} -->
<h6 class="kt-adv-heading7_0c4d1d-2c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_0c4d1d-2c">Learn</h6>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_b048ee-9d","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"mm-k nfi-file"} -->
<div class="kt-adv-heading7_b048ee-9d wp-block-kadence-advancedheading mm-k nfi-file" data-kb-block="kb-adv-heading7_b048ee-9d"><a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>"><strong>Blog</strong><br>Guides to recover lost sales.</a></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_05e00b-1a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"mm-k nfi-book"} -->
<div class="kt-adv-heading7_05e00b-1a wp-block-kadence-advancedheading mm-k nfi-book" data-kb-block="kb-adv-heading7_05e00b-1a"><a href="#nf-docs"><strong>Documentation</strong><br>Set up Notifima step by step.</a></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_61ab6f-e5","kbVersion":2,"className":"mg-group"} -->
<div class="wp-block-kadence-column kadence-column7_61ab6f-e5 mg-group"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"level":6,"uniqueID":"7_669dde-15","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}]} -->
<h6 class="kt-adv-heading7_669dde-15 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_669dde-15">Get help</h6>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_2493b1-3c","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"mm-k nfi-help"} -->
<div class="kt-adv-heading7_2493b1-3c wp-block-kadence-advancedheading mm-k nfi-help" data-kb-block="kb-adv-heading7_2493b1-3c"><a href="#nf-support"><strong>Support</strong><br>Talk to the Notifima team.</a></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_a89b31-3f","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"mm-k nfi-refresh"} -->
<div class="kt-adv-heading7_a89b31-3f wp-block-kadence-advancedheading mm-k nfi-refresh" data-kb-block="kb-adv-heading7_a89b31-3f"><a href="<?php echo esc_url( home_url( '/release-notes/' ) ); ?>"><strong>Release Notes</strong><br>What's new in each version.</a></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_0fc6dc-40","kbVersion":2,"className":"mg-group"} -->
<div class="wp-block-kadence-column kadence-column7_0fc6dc-40 mg-group"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"level":6,"uniqueID":"7_a21300-bd","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}]} -->
<h6 class="kt-adv-heading7_a21300-bd wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_a21300-bd">Company</h6>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_c37943-1a","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"mm-k nfi-users"} -->
<div class="kt-adv-heading7_c37943-1a wp-block-kadence-advancedheading mm-k nfi-users" data-kb-block="kb-adv-heading7_c37943-1a"><a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>"><strong>About Us</strong><br>The team behind Notifima.</a></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_4d7bb6-28","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"mm-k nfi-mail"} -->
<div class="kt-adv-heading7_4d7bb6-28 wp-block-kadence-advancedheading mm-k nfi-mail" data-kb-block="kb-adv-heading7_4d7bb6-28"><a href="#nf-contact"><strong>Contact Us</strong><br>Sales and partnerships.</a></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_48ca4d-ff","kbVersion":2,"className":"mg-foot"} -->
<div class="wp-block-kadence-column kadence-column7_48ca4d-ff mg-foot"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_e2f31e-0b","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"mg-ftx"} -->
<div class="kt-adv-heading7_e2f31e-0b wp-block-kadence-advancedheading mg-ftx" data-kb-block="kb-adv-heading7_e2f31e-0b"><strong>Try before you buy.</strong> Explore the live demo store.</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_4db18b-22","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","className":"link nfa"} -->
<div class="kt-adv-heading7_4db18b-22 wp-block-kadence-advancedheading link nfa" data-kb-block="kb-adv-heading7_4db18b-22"><a href="#nf-demo">Open live demo</a></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
