<?php
/**
 * Synced patterns: every Notifima pattern lives in WordPress, editable in Appearance → Design → Patterns
 * (category "Notifima"), like patterns you make yourself.
 *
 *   pattern-files/*.php   production PHP markup used to create editable synced patterns. They are NOT registered as theme
 *                         patterns, because WordPress shows theme patterns locked (read-only).
 *   On theme activation (and Appearance → Notifima → Create synced patterns) each file becomes a synced pattern
 *   (post type wp_block), only when it doesn't exist yet. "Put the original design back" overwrites them
 *   (WordPress keeps the old version as a revision).
 *   Only what repeats is a synced pattern: the header, the footer (with the call to action) and the sections that
 *   appear on more than one page (pricing plans, testimonials, trust strip). Every other section lives in its page
 *   (page-content/*.php), as normal Kadence blocks you edit right there.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;

/** Every pattern file: slug => [ 'title', 'description', 'file' ]. */
function nf_pattern_files() {
	static $list = null;
	if ( null === $list ) {
		$list = array();
		foreach ( (array) glob( NF_DIR . '/pattern-files/*.php' ) as $file ) {
			$head = get_file_data( $file, array( 'title' => 'Title', 'description' => 'Description' ) );
			$list[ basename( $file, '.php' ) ] = $head + array( 'file' => $file );
		}
	}
	return $list;
}

/** Block markup of a pattern file (the files echo their markup; links are resolved here). */
function nf_pattern_markup( $slug ) {
	$file = NF_DIR . '/pattern-files/' . sanitize_file_name( $slug ) . '.php';
	if ( ! file_exists( $file ) ) {
		return '';
	}
	ob_start();
	include $file;
	return trim( ob_get_clean() );
}

/** Block markup of a page (page-content/SLUG.php) with {{ref:…}} turned into its synced pattern. */
function nf_page_markup( $slug ) {
	$file = NF_DIR . '/page-content/' . sanitize_file_name( $slug ) . '.php';
	if ( ! file_exists( $file ) ) {
		$file = NF_DIR . '/data/page-extra/' . sanitize_file_name( $slug ) . '.php'; // pages kept outside the generated folder
	}
	if ( ! file_exists( $file ) ) {
		return '';
	}
	ob_start();
	include $file;
	$html = trim( ob_get_clean() );
	return preg_replace_callback(
		'/\{\{ref:([\w-]+)\}\}/',
		function ( $m ) {
			$id = nf_sync_pattern( $m[1] );
			return $id ? nf_pattern_ref( $id ) : nf_pattern_markup( $m[1] );
		},
		$html
	);
}

/** slug => synced pattern ID. */
function nf_synced_ids() {
	return (array) get_option( 'nf_synced_patterns', array() );
}

/** The synced pattern of a slug, or null when it was deleted / never made. */
function nf_synced_post( $slug ) {
	$ids  = nf_synced_ids();
	$post = empty( $ids[ $slug ] ) ? null : get_post( (int) $ids[ $slug ] );
	return ( $post && 'wp_block' === $post->post_type && 'trash' !== $post->post_status ) ? $post : null;
}

/** Markup that shows a synced pattern. */
function nf_pattern_ref( $id ) {
	return '<!-- wp:block {"ref":' . (int) $id . '} /-->';
}

/**
 * Make (or with $reset, put back) the synced pattern of one file. Returns its ID (0 on failure).
 */
function nf_sync_pattern( $slug, $reset = false ) {
	$files = nf_pattern_files();
	if ( ! isset( $files[ $slug ] ) ) {
		return 0;
	}
	$post = nf_synced_post( $slug );
	if ( $post && ! $reset ) {
		return $post->ID;
	}
	$content = nf_pattern_markup( $slug );
	if ( '' === $content ) {
		return 0;
	}
	$data = array(
		'post_type'    => 'wp_block',
		'post_status'  => 'publish',
		'post_title'   => $files[ $slug ]['title'],
		'post_excerpt' => $files[ $slug ]['description'],
		'post_content' => wp_slash( $content ),
	);
	if ( $post ) {
		$data['ID'] = $post->ID;
		$id         = wp_update_post( $data, true );
	} else {
		$id = wp_insert_post( $data, true );
	}
	if ( is_wp_error( $id ) || ! $id ) {
		return 0;
	}
	delete_post_meta( $id, 'wp_pattern_sync_status' ); // no meta = synced
	if ( taxonomy_exists( 'wp_pattern_category' ) ) {
		wp_set_object_terms( $id, 'Notifima', 'wp_pattern_category' );
	}
	update_post_meta( $id, '_nf_built_hash', md5( (string) get_post_field( 'post_content', $id ) ) );
	$ids          = nf_synced_ids();
	$ids[ $slug ] = (int) $id;
	update_option( 'nf_synced_patterns', $ids, false );
	return (int) $id;
}

/** All synced patterns (header, footer, shared sections). Returns how many exist afterwards. */
function nf_sync_all( $reset = false ) {
	$n = 0;
	foreach ( array_keys( nf_pattern_files() ) as $slug ) {
		if ( nf_sync_pattern( $slug, $reset ) ) {
			$n++;
		}
	}
	return $n;
}

/** Edit link of a synced pattern (block editor with Kadence). */
function nf_pattern_edit_url( $slug ) {
	$post = nf_synced_post( $slug );
	return $post ? admin_url( 'post.php?post=' . $post->ID . '&action=edit' ) : '';
}

/** Is this content built from our synced patterns? (for the full-width layout) */
function nf_uses_synced_pattern( $content ) {
	if ( false === strpos( $content, '<!-- wp:block {"ref":' ) || ! preg_match_all( '/<!-- wp:block \{"ref":(\d+)/', $content, $m ) ) {
		return false;
	}
	return (bool) array_intersect( array_map( 'intval', $m[1] ), array_map( 'intval', nf_synced_ids() ) );
}

/** Rendered HTML of a pattern by slug: the synced one (with your edits) or the original file. */
function nf_render_pattern( $slug ) {
	$post    = nf_synced_post( $slug );
	$content = $post && 'publish' === $post->post_status ? $post->post_content : nf_pattern_markup( $slug );
	return do_blocks( $content );
}
