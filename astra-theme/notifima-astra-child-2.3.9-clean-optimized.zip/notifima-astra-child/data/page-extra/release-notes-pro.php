<?php
/**
 * Notifima Pro Release Notes page content, stored as editable Kadence block markup.
 * After the page exists, add new versions in the page editor.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:kadence/rowlayout {"uniqueID":"7_938dda-63","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[170,28,80,28],"tabletPadding":[170,28,80,28],"mobilePadding":[140,18,56,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k phero"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"7_941a6c-2d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap rv"} -->
<div class="wp-block-kadence-column kadence-column7_941a6c-2d kb-section-dir-vertical wrap rv"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"7_fca38a-f5","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"div","align":"center","color":"var(\u002d\u002dmut)","fontSize":[14,"",""],"sizeType":"px","fontHeight":[23.1,"",""],"fontHeightType":"px","fontWeight":"400","margin":[4,0,0,0],"mobileMargin":[3,"","",""],"marginType":"px","className":"crumbs"} -->
<div class="kt-adv-heading7_fca38a-f5 wp-block-kadence-advancedheading crumbs" data-kb-block="kb-adv-heading7_fca38a-f5"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>/<a href="<?php echo esc_url( home_url( '/release-notes/' ) ); ?>">Release notes</a>/<span>Notifima Pro</span></div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"level":1,"uniqueID":"7_baf804-d2","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"align":"center","color":"var(\u002d\u002dast-global-color-2)","fontSize":[66,42.64,38],"sizeType":"px","fontHeight":[69.96,45.1984,40.28],"fontHeightType":"px","fontWeight":"500","letterSpacing":-1.98,"tabletLetterSpacing":-1.2792,"mobileLetterSpacing":-1.14,"margin":[18,0,0,0],"marginType":"px","markColor":"var(\u002d\u002dast-global-color-0)"} -->
<h1 class="kt-adv-heading7_baf804-d2 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading7_baf804-d2">Notifima Pro release <mark class="kt-highlight">notes</mark></h1>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"7_5cc378-37","markBorder":"","markBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"tabletMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"mobileMarkBorderStyles":[{"top":[null,"",""],"right":[null,"",""],"bottom":[null,"",""],"left":[null,"",""],"unit":"px"}],"htmlTag":"p","align":"center","color":"var(\u002d\u002dast-global-color-3)","fontSize":[19,"",""],"sizeType":"px","fontHeight":[31.35,"",""],"fontHeightType":"px","fontWeight":"400","margin":[19.9,0,0,0],"tabletMargin":[20,"","",""],"marginType":"px","className":"lead"} -->
<p class="kt-adv-heading7_5cc378-37 wp-block-kadence-advancedheading lead" data-kb-block="kb-adv-heading7_5cc378-37">Every update, fix and improvement to Notifima Pro, newest first.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->

<!-- wp:kadence/rowlayout {"uniqueID":"rp_74459c-a3","columns":1,"colLayout":"equal","align":"full","htmlTag":"section","padding":[24,28,104,28],"tabletPadding":[24,28,76,28],"mobilePadding":[16,18,76,18],"margin":[0,"",0,""],"inheritMaxWidth":true,"columnGutter":"none","collapseGutter":"none","kbVersion":2,"className":"nf-k nf-relpro-sec"} -->
<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_ccfc59-a5","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"wrap"} -->
<div class="wp-block-kadence-column kadence-columnrp_ccfc59-a5 kb-section-dir-vertical wrap"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_10ae9f-c7","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"nf-relpro"} -->
<div class="wp-block-kadence-column kadence-columnrp_10ae9f-c7 kb-section-dir-vertical nf-relpro"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_dfb3e8-c1","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_dfb3e8-c1 kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_73a47e-81","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_73a47e-81 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_73a47e-81">1.1.7</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_0a5d97-9a","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_0a5d97-9a rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_0a5d97-9a">3rd November, 2026</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WordPress 7.1.4.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Fixed - Fixed JavaScript loading issues on all frontend pages and checked functionality.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Update - Language file.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_3d1ebc-10","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_3d1ebc-10 kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_41799a-c1","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_41799a-c1 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_41799a-c1">1.1.6</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_a1a7d4-b5","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_a1a7d4-b5 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_a1a7d4-b5">23rd October, 2026</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WooCommerce 11.2.1.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - An “Restock Time” column to the Inventory Manager.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Automatic subscriber deletion functionality.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Update - Language file.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_f9e8ed-79","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_f9e8ed-79 kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_7ed608-15","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_7ed608-15 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_7ed608-15">1.1.5</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_67048c-21","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_67048c-21 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_67048c-21">7th October, 2026</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WordPress 7.1.3.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - New filter added to the Subscriber List table.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Update - Language file.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_28c7da-f2","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_28c7da-f2 kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_a73290-d6","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_a73290-d6 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_a73290-d6">1.1.4</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_8d13be-59","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_8d13be-59 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_8d13be-59">25th September, 2026</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WordPress 7.1.2.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Compatibility of WooCommerce 11.1.2.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - MCP support for enhanced integration and product stock notification management</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - SMS notifications for subscribed products when they are back in stock via Twilio and Vonage</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_411131-d7","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_411131-d7 kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_279c0b-ca","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_279c0b-ca rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_279c0b-ca">1.1.3</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_7cdc89-58","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_7cdc89-58 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_7cdc89-58">1st September, 2026</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Fixed - Resolved an issue where the product-wise set lead time was not displayed on the single product page.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_04e8dc-24","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_04e8dc-24 kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_642305-96","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_642305-96 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_642305-96">1.1.2</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_1406ea-79","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_1406ea-79 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_1406ea-79">21st August, 2026</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WordPress 7.1.0</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Compatibility of WooCommerce 11.0.1</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Fixed - Issue with the subscription unsubscribe flow from the My Account page.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_a2485a-5b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_a2485a-5b kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_f9b985-c8","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_f9b985-c8 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_f9b985-c8">1.1.1</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_15d247-05","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_15d247-05 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_15d247-05">21st July, 2026</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WordPress 7.0.2</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Compatibility of WooCommerce 10.9.4.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Subscriber count-based sorting functionality in the Inventory Manager</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_1dfe28-a3","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_1dfe28-a3 kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_c153ed-c6","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_c153ed-c6 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_c153ed-c6">1.1.0</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_771550-96","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_771550-96 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_771550-96">6th July, 2026</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WordPress 7.0.0</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Compatibility of WooCommerce 10.9.3.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Updated the overall UI/UX of the settings panel &amp; the other pages</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Support for marking products as discontinued to disable back-in-stock subscriptions</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_4ee4a5-06","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_4ee4a5-06 kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_6ba3c4-13","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_6ba3c4-13 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_6ba3c4-13">1.0.2</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_9b05c0-0c","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_9b05c0-0c rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_9b05c0-0c">16th July, 2025</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WordPress 6.9.1</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Compatibility of WooCommerce 10.5.1.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Fixed - Updated the license library.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_31db71-bf","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_31db71-bf kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_ad8c47-e0","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_ad8c47-e0 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_ad8c47-e0">1.0.1</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_07a7a5-a8","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_07a7a5-a8 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_07a7a5-a8">16th July, 2025</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WooCommerce 10.0.2.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Fixed - Error related to display_product_subscription_form.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"borderWidth":["","","",""],"uniqueID":"rp_b37d94-3f","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"rel"} -->
<div class="wp-block-kadence-column kadence-columnrp_b37d94-3f kb-section-dir-vertical rel"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"rp_4bd88e-e8","className":"rel-ver"} -->
<h2 class="kt-adv-headingrp_4bd88e-e8 rel-ver wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_4bd88e-e8">1.0.0</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"rp_480628-61","htmlTag":"div","className":"rel-date"} -->
<div class="kt-adv-headingrp_480628-61 rel-date wp-block-kadence-advancedheading" data-kb-block="kb-adv-headingrp_480628-61">8th July, 2025</div>
<!-- /wp:kadence/advancedheading -->

<!-- wp:list {"className":"rel-items"} -->
<ul class="wp-block-list rel-items"><!-- wp:list-item -->
<li>Added - Compatibility of WordPress 6.8.1</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Added - Compatibility of WooCommerce 9.9.5.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Update - Language file.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Enhanced - Enhanced Structure for improved navigation and usability.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Enhanced - Optimized Coding for better performance and stability.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- /wp:kadence/rowlayout -->
