<?php
/**
 * The sample blog post (Kadence blocks), created by Appearance → Notifima → Create the sample blog post.
 * Bundled sample content used by the theme admin action.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;

return array(
	'title'    => 'WooCommerce Out of Stock? How Back in Stock Alerts Win Back Lost Sales',
	'excerpt'  => 'Turn every stockout into a future sale: how WooCommerce back in stock alerts work, how to set them up, and how to use the waitlist to plan restocks.',
	'category' => 'Guides',
	'content'  => '<!-- wp:kadence/column {"uniqueID":"9_7d23b5-bf","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-banner rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_7d23b5-bf kb-section-dir-vertical bp-banner rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_025ab7-8d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-bn-card bp-bn-prod t-div"} -->
<div class="wp-block-kadence-column kadence-column9_025ab7-8d kb-section-dir-vertical bp-bn-card bp-bn-prod t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_75c268-22","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-bn-img t-div"} -->
<div class="wp-block-kadence-column kadence-column9_75c268-22 kb-section-dir-vertical bp-bn-img t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_1930b7-30","htmlTag":"span","className":"i nfi nfi-sneaker"} -->
<span class="kt-adv-heading9_1930b7-30 wp-block-kadence-advancedheading i nfi nfi-sneaker" data-kb-block="kb-adv-heading9_1930b7-30"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_1bfadc-50","htmlTag":"div","className":"t-div"} -->
<div class="kt-adv-heading9_1bfadc-50 wp-block-kadence-advancedheading t-div" data-kb-block="kb-adv-heading9_1bfadc-50"><b>Trail Runner 2</b><small>Size 42 · Black</small><span class="tag bad">Out of stock</span></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_691b68-58","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-bn-card bp-bn-form t-div"} -->
<div class="wp-block-kadence-column kadence-column9_691b68-58 kb-section-dir-vertical bp-bn-card bp-bn-form t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_409423-59","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_409423-59 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_409423-59"><span class="bp-bn-k">Notify me when available</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_e128ec-14","htmlTag":"div","className":"bp-bn-inp t-div"} -->
<div class="kt-adv-heading9_e128ec-14 wp-block-kadence-advancedheading bp-bn-inp t-div" data-kb-block="kb-adv-heading9_e128ec-14">ada@example.com</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_8d2ab3-b5","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-bn-btn t-div"} -->
<div class="wp-block-kadence-column kadence-column9_8d2ab3-b5 kb-section-dir-vertical bp-bn-btn t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_4e208b-ba","htmlTag":"span","className":"i nfi nfi-bell"} -->
<span class="kt-adv-heading9_4e208b-ba wp-block-kadence-advancedheading i nfi nfi-bell" data-kb-block="kb-adv-heading9_4e208b-ba"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_da63b5-ba","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_da63b5-ba wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_da63b5-ba">Notify me</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_c20f37-bd","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-bn-chip bp-bn-c1 t-div"} -->
<div class="wp-block-kadence-column kadence-column9_c20f37-bd kb-section-dir-vertical bp-bn-chip bp-bn-c1 t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_7d2925-f9","htmlTag":"span","className":"i nfi nfi-users"} -->
<span class="kt-adv-heading9_7d2925-f9 wp-block-kadence-advancedheading i nfi nfi-users" data-kb-block="kb-adv-heading9_7d2925-f9"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_885133-c7","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_885133-c7 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_885133-c7"><span><b>148 waiting</b><small>for this product</small></span></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_2bf144-d4","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-bn-chip bp-bn-c2 t-div"} -->
<div class="wp-block-kadence-column kadence-column9_2bf144-d4 kb-section-dir-vertical bp-bn-chip bp-bn-c2 t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_aefdb3-e6","htmlTag":"span","className":"i nfi nfi-mail"} -->
<span class="kt-adv-heading9_aefdb3-e6 wp-block-kadence-advancedheading i nfi nfi-mail" data-kb-block="kb-adv-heading9_aefdb3-e6"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_7b5422-e8","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_7b5422-e8 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_7b5422-e8"><span><b>Back in stock!</b><small>sent to 148 shoppers</small></span></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_10319c-a9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-bn-chip bp-bn-c3 t-div"} -->
<div class="wp-block-kadence-column kadence-column9_10319c-a9 kb-section-dir-vertical bp-bn-chip bp-bn-c3 t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_e1f6e2-fa","htmlTag":"span","className":"i nfi nfi-cart"} -->
<span class="kt-adv-heading9_e1f6e2-fa wp-block-kadence-advancedheading i nfi nfi-cart" data-kb-block="kb-adv-heading9_e1f6e2-fa"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_d1c208-db","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_d1c208-db wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_d1c208-db"><span><b>+$4,210</b><small>recovered this week</small></span></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_693b72-e4","htmlTag":"p","className":"bp-lead t-p"} -->
<p class="kt-adv-heading9_693b72-e4 wp-block-kadence-advancedheading bp-lead t-p" data-kb-block="kb-adv-heading9_693b72-e4">A shopper finds the product they want, picks a size, and sees <b>"Out of stock"</b>. <span class="ac">What happens next decides whether you ever see that sale.</span></p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_f216b2-21","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_f216b2-21 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_f216b2-21">Most stores give that shopper nothing to do. There is no button, no date, no way to stay in touch. So they leave, search for the same product somewhere else, and buy it there.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_3a5759-0b","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_3a5759-0b wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_3a5759-0b">A stockout is not the end of the sale. It is a pause. Back in stock alerts turn that pause into a list of people who have already said "I want this", and bring them back the moment you restock.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"uniqueID":"9_f5b891-70","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-compare rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_f5b891-70 kb-section-dir-vertical bp-compare rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_98c160-29","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-cmp bad t-div"} -->
<div class="wp-block-kadence-column kadence-column9_98c160-29 kb-section-dir-vertical bp-cmp bad t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_9f55eb-62","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_9f55eb-62 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_9f55eb-62"><span class="bp-cmp-k">Without alerts</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_68e885-94","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-ol"} -->
<div class="wp-block-kadence-column kadence-column9_68e885-94 kb-section-dir-vertical t-ol"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_bf696d-6f","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_bf696d-6f wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_bf696d-6f">Shopper sees "Out of stock"</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_ba75bf-2d","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_ba75bf-2d wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_ba75bf-2d">Nothing to do on the page</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_c0d06b-fc","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_c0d06b-fc wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_c0d06b-fc">Leaves and searches elsewhere</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_ee9ddc-4c","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_ee9ddc-4c wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_ee9ddc-4c">Buys from a competitor</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_52c86f-4f","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-cmp-r t-div"} -->
<div class="wp-block-kadence-column kadence-column9_52c86f-4f kb-section-dir-vertical bp-cmp-r t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_694981-21","htmlTag":"span","className":"i nfi nfi-x"} -->
<span class="kt-adv-heading9_694981-21 wp-block-kadence-advancedheading i nfi nfi-x" data-kb-block="kb-adv-heading9_694981-21"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_3d7ed1-c3","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_3d7ed1-c3 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_3d7ed1-c3">The sale is gone</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_c7b2ee-6a","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-cmp good t-div"} -->
<div class="wp-block-kadence-column kadence-column9_c7b2ee-6a kb-section-dir-vertical bp-cmp good t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_8c91a7-ae","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_8c91a7-ae wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_8c91a7-ae"><span class="bp-cmp-k">With alerts</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_509603-f8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-ol"} -->
<div class="wp-block-kadence-column kadence-column9_509603-f8 kb-section-dir-vertical t-ol"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_8ec7bf-cc","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_8ec7bf-cc wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_8ec7bf-cc">Shopper sees "Out of stock"</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_85a11a-d4","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_85a11a-d4 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_85a11a-d4">Clicks "Notify me" and leaves an email</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_d8de01-80","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_d8de01-80 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_d8de01-80">Gets an email when you restock</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_99171c-da","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_99171c-da wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_99171c-da">Comes back and buys</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_5469bf-1b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-cmp-r t-div"} -->
<div class="wp-block-kadence-column kadence-column9_5469bf-1b kb-section-dir-vertical bp-cmp-r t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_f9d322-0d","htmlTag":"span","className":"i nfi nfi-check"} -->
<span class="kt-adv-heading9_f9d322-0d wp-block-kadence-advancedheading i nfi nfi-check" data-kb-block="kb-adv-heading9_f9d322-0d"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_f90c0b-a4","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_f90c0b-a4 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_f90c0b-a4">The sale is saved</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_739756-af","level":2,"anchor":"why","className":"t-h2"} -->
<h2 id="why" class="kt-adv-heading9_739756-af wp-block-kadence-advancedheading t-h2" data-kb-block="kb-adv-heading9_739756-af">Why stockouts cost more than one sale</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_13d4f8-b2","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_13d4f8-b2 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_13d4f8-b2">When a product sells out, the lost order is only the part you can see. The rest is harder to measure:</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"uniqueID":"9_c9ed5c-a5","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-chips rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_c9ed5c-a5 kb-section-dir-vertical bp-chips rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_4b30b8-5f","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_4b30b8-5f kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_9bb439-07","htmlTag":"span","className":"i nfi nfi-cart"} -->
<span class="kt-adv-heading9_9bb439-07 wp-block-kadence-advancedheading i nfi nfi-cart" data-kb-block="kb-adv-heading9_9bb439-07"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_3df65c-d7","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_3df65c-d7 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_3df65c-d7">Lost orders</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_3e7691-9e","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_3e7691-9e kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_8039e8-77","htmlTag":"span","className":"i nfi nfi-users"} -->
<span class="kt-adv-heading9_8039e8-77 wp-block-kadence-advancedheading i nfi nfi-users" data-kb-block="kb-adv-heading9_8039e8-77"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_205a94-6b","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_205a94-6b wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_205a94-6b">Lost customers</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_03ee76-b0","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_03ee76-b0 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_ba3cf0-54","htmlTag":"span","className":"i nfi nfi-trenddown"} -->
<span class="kt-adv-heading9_ba3cf0-54 wp-block-kadence-advancedheading i nfi nfi-trenddown" data-kb-block="kb-adv-heading9_ba3cf0-54"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_79319e-44","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_79319e-44 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_79319e-44">Lower search ranking</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_f6a25f-26","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_f6a25f-26 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_f18fb7-ed","htmlTag":"span","className":"i nfi nfi-refresh"} -->
<span class="kt-adv-heading9_f18fb7-ed wp-block-kadence-advancedheading i nfi nfi-refresh" data-kb-block="kb-adv-heading9_f18fb7-ed"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_c02273-12","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_c02273-12 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_c02273-12">Wasted ad spend</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_0543af-a4","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_0543af-a4 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_7ae566-2f","htmlTag":"span","className":"i nfi nfi-help"} -->
<span class="kt-adv-heading9_7ae566-2f wp-block-kadence-advancedheading i nfi nfi-help" data-kb-block="kb-adv-heading9_7ae566-2f"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_82649e-94","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_82649e-94 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_82649e-94">More support tickets</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_467092-b9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_467092-b9 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_2a87bc-09","htmlTag":"span","className":"i nfi nfi-chart"} -->
<span class="kt-adv-heading9_2a87bc-09 wp-block-kadence-advancedheading i nfi nfi-chart" data-kb-block="kb-adv-heading9_2a87bc-09"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_5af729-05","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_5af729-05 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_5af729-05">No idea of real demand</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_8a02ca-f2","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_8a02ca-f2 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_6a1626-52","htmlTag":"span","className":"i nfi nfi-heart"} -->
<span class="kt-adv-heading9_6a1626-52 wp-block-kadence-advancedheading i nfi nfi-heart" data-kb-block="kb-adv-heading9_6a1626-52"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_272d27-69","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_272d27-69 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_272d27-69">Less brand trust</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_31a093-16","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_31a093-16 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_fb1c7c-02","htmlTag":"span","className":"i nfi nfi-package"} -->
<span class="kt-adv-heading9_fb1c7c-02 wp-block-kadence-advancedheading i nfi nfi-package" data-kb-block="kb-adv-heading9_fb1c7c-02"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_1863be-49","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_1863be-49 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_1863be-49">Wrong restock amounts</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_0f168f-6c","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_0f168f-6c wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_0f168f-6c">The last one is easy to miss. If you can\'t see how many people wanted a product while it was gone, you can\'t tell whether to reorder 20 units or 200.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"uniqueID":"9_33ce14-80","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-stats rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_33ce14-80 kb-section-dir-vertical bp-stats rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_6e66b6-e4","htmlTag":"div","className":"t-div"} -->
<div class="kt-adv-heading9_6e66b6-e4 wp-block-kadence-advancedheading t-div" data-kb-block="kb-adv-heading9_6e66b6-e4"><b>1 in 3</b><span>shoppers who meet a stockout buy the item somewhere else</span></div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_c49021-76","htmlTag":"div","className":"t-div"} -->
<div class="kt-adv-heading9_c49021-76 wp-block-kadence-advancedheading t-div" data-kb-block="kb-adv-heading9_c49021-76"><b>148</b><span>people waiting on one popular size in the example above</span></div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_cd390b-1c","htmlTag":"div","className":"t-div"} -->
<div class="kt-adv-heading9_cd390b-1c wp-block-kadence-advancedheading t-div" data-kb-block="kb-adv-heading9_cd390b-1c"><b>1 click</b><span>from the restock email back to the product page</span></div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"uniqueID":"9_f2b4d9-72","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-note rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_f2b4d9-72 kb-section-dir-vertical bp-note rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_30406b-f1","htmlTag":"span","className":"i nfi nfi-bulb"} -->
<span class="kt-adv-heading9_30406b-f1 wp-block-kadence-advancedheading i nfi nfi-bulb" data-kb-block="kb-adv-heading9_30406b-f1"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_0e9b99-23","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-div"} -->
<div class="wp-block-kadence-column kadence-column9_0e9b99-23 kb-section-dir-vertical t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_670dca-22","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_670dca-22 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_670dca-22"><b>Good to know</b></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_e29254-94","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_e29254-94 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_e29254-94">Shoppers who join a waitlist have already chosen the product, the size and the colour. They are some of the warmest leads your store will ever have.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_51fc5a-c5","level":2,"anchor":"how","className":"t-h2"} -->
<h2 id="how" class="kt-adv-heading9_51fc5a-c5 wp-block-kadence-advancedheading t-h2" data-kb-block="kb-adv-heading9_51fc5a-c5">How back in stock alerts work</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_ebf201-68","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_ebf201-68 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_ebf201-68">The idea is simple. When a product or variation is out of stock, the product page shows a small form instead of a dead end. The rest happens on its own:</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"uniqueID":"9_6a2644-ff","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-flow rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_6a2644-ff kb-section-dir-vertical bp-flow rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_5bebfe-fb","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_5bebfe-fb wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_5bebfe-fb"><span>Product sells out</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_548db0-26","htmlTag":"span","className":"i nfi nfi-arrow"} -->
<span class="kt-adv-heading9_548db0-26 wp-block-kadence-advancedheading i nfi nfi-arrow" data-kb-block="kb-adv-heading9_548db0-26"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_40c2ba-3f","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_40c2ba-3f wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_40c2ba-3f"><span>Shopper subscribes</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_140b45-9f","htmlTag":"span","className":"i nfi nfi-arrow"} -->
<span class="kt-adv-heading9_140b45-9f wp-block-kadence-advancedheading i nfi nfi-arrow" data-kb-block="kb-adv-heading9_140b45-9f"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_811a31-6a","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_811a31-6a wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_811a31-6a"><span>You restock</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_600856-79","htmlTag":"span","className":"i nfi nfi-arrow"} -->
<span class="kt-adv-heading9_600856-79 wp-block-kadence-advancedheading i nfi nfi-arrow" data-kb-block="kb-adv-heading9_600856-79"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_057a1e-de","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_057a1e-de wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_057a1e-de"><span>Email goes out</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_16a205-e1","htmlTag":"span","className":"i nfi nfi-arrow"} -->
<span class="kt-adv-heading9_16a205-e1 wp-block-kadence-advancedheading i nfi nfi-arrow" data-kb-block="kb-adv-heading9_16a205-e1"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_2a2cc9-73","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_2a2cc9-73 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_2a2cc9-73"><span class="on">Shopper buys</span></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"uniqueID":"9_7ea134-3d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-steps rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_7ea134-3d kb-section-dir-vertical bp-steps rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_11071b-10","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-step t-div"} -->
<div class="wp-block-kadence-column kadence-column9_11071b-10 kb-section-dir-vertical bp-step t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_19b1e5-11","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_19b1e5-11 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_19b1e5-11"><span class="bp-n">01</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_d6db08-58","level":3,"className":"t-h3"} -->
<h3 class="kt-adv-heading9_d6db08-58 wp-block-kadence-advancedheading t-h3" data-kb-block="kb-adv-heading9_d6db08-58">Show the form</h3>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_d82860-70","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_d82860-70 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_d82860-70">A "Notify me" form appears on every out-of-stock product and variation, styled to match your theme.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_3933cb-b9","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-step t-div"} -->
<div class="wp-block-kadence-column kadence-column9_3933cb-b9 kb-section-dir-vertical bp-step t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_b1144e-d5","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_b1144e-d5 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_b1144e-d5"><span class="bp-n">02</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_b60884-fe","level":3,"className":"t-h3"} -->
<h3 class="kt-adv-heading9_b60884-fe wp-block-kadence-advancedheading t-h3" data-kb-block="kb-adv-heading9_b60884-fe">Collect the email</h3>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_e6ea14-ac","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_e6ea14-ac wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_e6ea14-ac">The shopper enters an email. Double opt-in and reCAPTCHA keep the list real and free of spam.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_595a3d-84","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-step t-div"} -->
<div class="wp-block-kadence-column kadence-column9_595a3d-84 kb-section-dir-vertical bp-step t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_8e5b8a-03","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_8e5b8a-03 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_8e5b8a-03"><span class="bp-n">03</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_dfc9f3-b7","level":3,"className":"t-h3"} -->
<h3 class="kt-adv-heading9_dfc9f3-b7 wp-block-kadence-advancedheading t-h3" data-kb-block="kb-adv-heading9_dfc9f3-b7">Restock as usual</h3>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_559ae3-33","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_559ae3-33 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_559ae3-33">Update the stock in WooCommerce like you always do. There is nothing extra to remember.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_6df6bb-c4","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-step t-div"} -->
<div class="wp-block-kadence-column kadence-column9_6df6bb-c4 kb-section-dir-vertical bp-step t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_2fa489-68","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_2fa489-68 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_2fa489-68"><span class="bp-n">04</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_efc7aa-8e","level":3,"className":"t-h3"} -->
<h3 class="kt-adv-heading9_efc7aa-8e wp-block-kadence-advancedheading t-h3" data-kb-block="kb-adv-heading9_efc7aa-8e">Alerts go out</h3>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_356492-c1","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_356492-c1 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_356492-c1">Everyone on the waitlist gets an email with a direct link back to the product, right away.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_3ca35e-1b","level":2,"anchor":"setup","className":"t-h2"} -->
<h2 id="setup" class="kt-adv-heading9_3ca35e-1b wp-block-kadence-advancedheading t-h2" data-kb-block="kb-adv-heading9_3ca35e-1b">Set it up in WooCommerce</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_5c04e5-ca","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_5c04e5-ca wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_5c04e5-ca">With Notifima, the whole setup takes a few minutes and needs no code.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"uniqueID":"9_0233af-2b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-ol t-ol"} -->
<div class="wp-block-kadence-column kadence-column9_0233af-2b kb-section-dir-vertical bp-ol t-ol"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_fa2834-74","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_fa2834-74 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_fa2834-74"><b>Install Notifima</b> from WordPress.org and activate it.</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_a18403-d9","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_a18403-d9 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_a18403-d9"><b>Turn on the form</b> under Notifima → Settings. Pick which products and variations it shows on.</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_004291-97","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_004291-97 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_004291-97"><b>Write the email</b>. Use the product name, image and link tags so every alert is personal.</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_903aa4-1d","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_903aa4-1d wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_903aa4-1d"><b>Add protection</b>. Switch on double opt-in and reCAPTCHA.</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_c3633c-c3","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_c3633c-c3 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_c3633c-c3"><b>Test it</b>. Mark a test product out of stock, subscribe, restock it, and check your inbox.</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"uniqueID":"9_b8c6e7-fc","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-code rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_b8c6e7-fc kb-section-dir-vertical bp-code rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_086ea0-9a","htmlTag":"div","className":"bp-code-h t-div"} -->
<div class="kt-adv-heading9_086ea0-9a wp-block-kadence-advancedheading bp-code-h t-div" data-kb-block="kb-adv-heading9_086ea0-9a"><span><i></i><i></i><i></i></span>Email subject</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_e930a7-05","htmlTag":"div","className":"t-pre"} -->
<div class="kt-adv-heading9_e930a7-05 wp-block-kadence-advancedheading t-pre" data-kb-block="kb-adv-heading9_e930a7-05">Good news, {first_name}! {product_name} is back in stock</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"uniqueID":"9_718af9-46","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-note warn rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_718af9-46 kb-section-dir-vertical bp-note warn rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_a705b8-76","htmlTag":"span","className":"i nfi nfi-alert"} -->
<span class="kt-adv-heading9_a705b8-76 wp-block-kadence-advancedheading i nfi nfi-alert" data-kb-block="kb-adv-heading9_a705b8-76"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_bc6076-63","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-div"} -->
<div class="wp-block-kadence-column kadence-column9_bc6076-63 kb-section-dir-vertical t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_7157c1-4b","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_7157c1-4b wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_7157c1-4b"><b>Watch out</b></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_da77dd-81","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_da77dd-81 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_da77dd-81">Send alerts as soon as stock arrives. If you wait a day, the first shoppers to come back may find the product sold out again.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_5708c5-24","level":2,"anchor":"demand","className":"t-h2"} -->
<h2 id="demand" class="kt-adv-heading9_5708c5-24 wp-block-kadence-advancedheading t-h2" data-kb-block="kb-adv-heading9_5708c5-24">Use the waitlist to plan restocks</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_2ef4a1-f7","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_2ef4a1-f7 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_2ef4a1-f7">Every subscription is a vote for a product. Notifima\'s demand tracking turns those votes into a list you can act on.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"uniqueID":"9_bcd1d8-e4","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-table rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_bcd1d8-e4 kb-section-dir-vertical bp-table rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_eb0738-7e","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-table"} -->
<div class="wp-block-kadence-column kadence-column9_eb0738-7e kb-section-dir-vertical t-table"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_3af10a-3a","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-thead"} -->
<div class="wp-block-kadence-column kadence-column9_3af10a-3a kb-section-dir-vertical t-thead"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_f4b076-33","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-tr cols-4"} -->
<div class="wp-block-kadence-column kadence-column9_f4b076-33 kb-section-dir-vertical t-tr cols-4"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_0fb8b8-82","htmlTag":"div","className":"t-th"} -->
<div class="kt-adv-heading9_0fb8b8-82 wp-block-kadence-advancedheading t-th" data-kb-block="kb-adv-heading9_0fb8b8-82">Product</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_d8737b-4d","htmlTag":"div","className":"t-th"} -->
<div class="kt-adv-heading9_d8737b-4d wp-block-kadence-advancedheading t-th" data-kb-block="kb-adv-heading9_d8737b-4d">Waiting</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_c2a0d7-74","htmlTag":"div","className":"t-th"} -->
<div class="kt-adv-heading9_c2a0d7-74 wp-block-kadence-advancedheading t-th" data-kb-block="kb-adv-heading9_c2a0d7-74">Trend</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_075a34-45","htmlTag":"div","className":"t-th"} -->
<div class="kt-adv-heading9_075a34-45 wp-block-kadence-advancedheading t-th" data-kb-block="kb-adv-heading9_075a34-45">Action</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_c99789-ab","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-tbody"} -->
<div class="wp-block-kadence-column kadence-column9_c99789-ab kb-section-dir-vertical t-tbody"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_d94ced-73","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-tr cols-4"} -->
<div class="wp-block-kadence-column kadence-column9_d94ced-73 kb-section-dir-vertical t-tr cols-4"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_b620ca-3f","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_b620ca-3f wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_b620ca-3f">Trail Runner 2 · 42</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_92e852-d0","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_92e852-d0 wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_92e852-d0">148</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_0f38e4-57","htmlTag":"div","className":"up t-td"} -->
<div class="kt-adv-heading9_0f38e4-57 wp-block-kadence-advancedheading up t-td" data-kb-block="kb-adv-heading9_0f38e4-57">+32 this week</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_9eface-9c","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_9eface-9c wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_9eface-9c">Reorder now</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_738fd1-b8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-tr cols-4"} -->
<div class="wp-block-kadence-column kadence-column9_738fd1-b8 kb-section-dir-vertical t-tr cols-4"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_bdb34c-02","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_bdb34c-02 wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_bdb34c-02">Linen Shirt · M</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_82fac8-e6","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_82fac8-e6 wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_82fac8-e6">61</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_d2b6ac-65","htmlTag":"div","className":"up t-td"} -->
<div class="kt-adv-heading9_d2b6ac-65 wp-block-kadence-advancedheading up t-td" data-kb-block="kb-adv-heading9_d2b6ac-65">+9 this week</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_554363-61","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_554363-61 wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_554363-61">Reorder soon</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_956541-55","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-tr cols-4"} -->
<div class="wp-block-kadence-column kadence-column9_956541-55 kb-section-dir-vertical t-tr cols-4"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_2d85fc-fa","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_2d85fc-fa wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_2d85fc-fa">Desk Lamp · Brass</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_712923-39","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_712923-39 wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_712923-39">12</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_6848f6-03","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_6848f6-03 wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_6848f6-03">Steady</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_cca26d-a7","htmlTag":"div","className":"t-td"} -->
<div class="kt-adv-heading9_cca26d-a7 wp-block-kadence-advancedheading t-td" data-kb-block="kb-adv-heading9_cca26d-a7">Watch</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_14e7d4-d3","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_14e7d4-d3 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_14e7d4-d3">Export the list, sync it to Mailchimp, or simply sort by "Waiting" before you place your next order.</p>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_e110ae-46","level":2,"anchor":"mistakes","className":"t-h2"} -->
<h2 id="mistakes" class="kt-adv-heading9_e110ae-46 wp-block-kadence-advancedheading t-h2" data-kb-block="kb-adv-heading9_e110ae-46">Common mistakes to avoid</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"uniqueID":"9_19d299-f5","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-mist rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_19d299-f5 kb-section-dir-vertical bp-mist rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_1cad97-13","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-div"} -->
<div class="wp-block-kadence-column kadence-column9_1cad97-13 kb-section-dir-vertical t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_0ca148-25","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_0ca148-25 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_cdb242-bb","htmlTag":"span","className":"i nfi nfi-x"} -->
<span class="kt-adv-heading9_cdb242-bb wp-block-kadence-advancedheading i nfi nfi-x" data-kb-block="kb-adv-heading9_cdb242-bb"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_c6cdfc-57","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_c6cdfc-57 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_c6cdfc-57"><b>Hiding out-of-stock products.</b> The page and its search ranking disappear, and so does the chance to collect emails.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_0be84a-cf","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-div"} -->
<div class="wp-block-kadence-column kadence-column9_0be84a-cf kb-section-dir-vertical t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_6ec9e6-1d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_6ec9e6-1d kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_1e4280-92","htmlTag":"span","className":"i nfi nfi-x"} -->
<span class="kt-adv-heading9_1e4280-92 wp-block-kadence-advancedheading i nfi nfi-x" data-kb-block="kb-adv-heading9_1e4280-92"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_7e622f-82","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_7e622f-82 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_7e622f-82"><b>Asking for too much.</b> An email is enough. Every extra field means fewer sign-ups.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_0adcdc-1e","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-div"} -->
<div class="wp-block-kadence-column kadence-column9_0adcdc-1e kb-section-dir-vertical t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_a917a0-a2","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_a917a0-a2 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_e059b2-2c","htmlTag":"span","className":"i nfi nfi-x"} -->
<span class="kt-adv-heading9_e059b2-2c wp-block-kadence-advancedheading i nfi nfi-x" data-kb-block="kb-adv-heading9_e059b2-2c"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_a80898-0b","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_a80898-0b wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_a80898-0b"><b>A plain, generic email.</b> Show the product, its image and one clear "Buy now" button.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_8219bd-bc","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-div"} -->
<div class="wp-block-kadence-column kadence-column9_8219bd-bc kb-section-dir-vertical t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_1716d6-c4","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-span"} -->
<div class="wp-block-kadence-column kadence-column9_1716d6-c4 kb-section-dir-vertical t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_584ad9-a0","htmlTag":"span","className":"i nfi nfi-x"} -->
<span class="kt-adv-heading9_584ad9-a0 wp-block-kadence-advancedheading i nfi nfi-x" data-kb-block="kb-adv-heading9_584ad9-a0"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_11407f-f5","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_11407f-f5 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_11407f-f5"><b>No spam protection.</b> Bots fill unprotected forms and hurt your sender reputation.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"uniqueID":"9_e382d8-f6","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-take rv t-div"} -->
<div class="wp-block-kadence-column kadence-column9_e382d8-f6 kb-section-dir-vertical bp-take rv t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_7a825a-cf","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-h3"} -->
<div class="wp-block-kadence-column kadence-column9_7a825a-cf kb-section-dir-vertical t-h3"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_29e6f2-b6","htmlTag":"span","className":"i nfi nfi-checks"} -->
<span class="kt-adv-heading9_29e6f2-b6 wp-block-kadence-advancedheading i nfi nfi-checks" data-kb-block="kb-adv-heading9_29e6f2-b6"></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_6ddf36-25","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_6ddf36-25 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_6ddf36-25">Key takeaways</span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_739d0b-ab","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-ul"} -->
<div class="wp-block-kadence-column kadence-column9_739d0b-ab kb-section-dir-vertical t-ul"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_7e1989-46","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_7e1989-46 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_7e1989-46">A stockout is a pause in the sale, not the end of it.</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_194afb-8b","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_194afb-8b wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_194afb-8b">A "Notify me" form keeps shoppers who would otherwise leave.</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_63fb2f-ac","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_63fb2f-ac wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_63fb2f-ac">Alerts should go out automatically the moment you restock.</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_4f4a5f-05","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_4f4a5f-05 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_4f4a5f-05">Double opt-in and reCAPTCHA keep your waitlist clean.</div>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_acc372-79","htmlTag":"div","className":"t-li"} -->
<div class="kt-adv-heading9_acc372-79 wp-block-kadence-advancedheading t-li" data-kb-block="kb-adv-heading9_acc372-79">The waitlist tells you exactly what to reorder, and how much.</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/advancedheading {"uniqueID":"9_ab3c71-d8","level":2,"anchor":"faq","className":"t-h2"} -->
<h2 id="faq" class="kt-adv-heading9_ab3c71-d8 wp-block-kadence-advancedheading t-h2" data-kb-block="kb-adv-heading9_ab3c71-d8">Frequently asked questions</h2>
<!-- /wp:kadence/advancedheading -->

<!-- wp:kadence/column {"uniqueID":"9_33d137-b5","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"faq bp-faq t-div"} -->
<div class="wp-block-kadence-column kadence-column9_33d137-b5 kb-section-dir-vertical faq bp-faq t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_fd0974-39","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"qa t-div"} -->
<div class="wp-block-kadence-column kadence-column9_fd0974-39 kb-section-dir-vertical qa t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_196032-8d","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"qa-q t-button"} -->
<div class="wp-block-kadence-column kadence-column9_196032-8d kb-section-dir-vertical qa-q t-button"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_09a80a-bf","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_09a80a-bf wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_09a80a-bf">Does it work with product variations?</span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_c58e54-e2","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"pm t-span"} -->
<div class="wp-block-kadence-column kadence-column9_c58e54-e2 kb-section-dir-vertical pm t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_2d278b-c4","htmlTag":"span","className":"i nfi nfi-plus"} -->
<span class="kt-adv-heading9_2d278b-c4 wp-block-kadence-advancedheading i nfi nfi-plus" data-kb-block="kb-adv-heading9_2d278b-c4"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_a02549-97","htmlTag":"div","className":"qa-a t-div"} -->
<div class="kt-adv-heading9_a02549-97 wp-block-kadence-advancedheading qa-a t-div" data-kb-block="kb-adv-heading9_a02549-97">Yes. Shoppers subscribe to the exact size or colour they want, and only get an email when that variation is back.</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_a02cc3-4a","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"qa t-div"} -->
<div class="wp-block-kadence-column kadence-column9_a02cc3-4a kb-section-dir-vertical qa t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_cf3fd1-68","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"qa-q t-button"} -->
<div class="wp-block-kadence-column kadence-column9_cf3fd1-68 kb-section-dir-vertical qa-q t-button"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_ba6d1e-be","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_ba6d1e-be wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_ba6d1e-be">Will it slow down my store?</span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_37aca4-3b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"pm t-span"} -->
<div class="wp-block-kadence-column kadence-column9_37aca4-3b kb-section-dir-vertical pm t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_9d4d74-ab","htmlTag":"span","className":"i nfi nfi-plus"} -->
<span class="kt-adv-heading9_9d4d74-ab wp-block-kadence-advancedheading i nfi nfi-plus" data-kb-block="kb-adv-heading9_9d4d74-ab"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_300ea9-0e","htmlTag":"div","className":"qa-a t-div"} -->
<div class="kt-adv-heading9_300ea9-0e wp-block-kadence-advancedheading qa-a t-div" data-kb-block="kb-adv-heading9_300ea9-0e">No. The form is small and only loads on out-of-stock products. Emails are sent in the background.</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_880e50-fa","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"qa t-div"} -->
<div class="wp-block-kadence-column kadence-column9_880e50-fa kb-section-dir-vertical qa t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_35445c-7b","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"qa-q t-button"} -->
<div class="wp-block-kadence-column kadence-column9_35445c-7b kb-section-dir-vertical qa-q t-button"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_9c7c31-98","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_9c7c31-98 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_9c7c31-98">Can I use my own email design?</span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_f3532a-f3","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"pm t-span"} -->
<div class="wp-block-kadence-column kadence-column9_f3532a-f3 kb-section-dir-vertical pm t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_3b4a1b-63","htmlTag":"span","className":"i nfi nfi-plus"} -->
<span class="kt-adv-heading9_3b4a1b-63 wp-block-kadence-advancedheading i nfi nfi-plus" data-kb-block="kb-adv-heading9_3b4a1b-63"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_130927-4b","htmlTag":"div","className":"qa-a t-div"} -->
<div class="kt-adv-heading9_130927-4b wp-block-kadence-advancedheading qa-a t-div" data-kb-block="kb-adv-heading9_130927-4b">Yes. Edit the subject and body with tags for the product name, image, price and link, or use your WooCommerce email template.</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/column {"uniqueID":"9_827323-73","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"qa t-div"} -->
<div class="wp-block-kadence-column kadence-column9_827323-73 kb-section-dir-vertical qa t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/column {"uniqueID":"9_9fd968-2c","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"qa-q t-button"} -->
<div class="wp-block-kadence-column kadence-column9_9fd968-2c kb-section-dir-vertical qa-q t-button"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_7c9094-98","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_7c9094-98 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_7c9094-98">Is it GDPR friendly?</span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_a6f97b-2c","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"pm t-span"} -->
<div class="wp-block-kadence-column kadence-column9_a6f97b-2c kb-section-dir-vertical pm t-span"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_9485ef-51","htmlTag":"span","className":"i nfi nfi-plus"} -->
<span class="kt-adv-heading9_9485ef-51 wp-block-kadence-advancedheading i nfi nfi-plus" data-kb-block="kb-adv-heading9_9485ef-51"></span>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_413bf3-67","htmlTag":"div","className":"qa-a t-div"} -->
<div class="kt-adv-heading9_413bf3-67 wp-block-kadence-advancedheading qa-a t-div" data-kb-block="kb-adv-heading9_413bf3-67">Yes. Double opt-in, a consent checkbox and one-click unsubscribe are built in.</div>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->

<!-- wp:kadence/column {"uniqueID":"9_86e8b9-2e","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"bp-author t-div"} -->
<div class="wp-block-kadence-column kadence-column9_86e8b9-2e kb-section-dir-vertical bp-author t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_39b3c0-8a","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_39b3c0-8a wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_39b3c0-8a"><span class="bp-av">N</span></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/column {"uniqueID":"9_228cec-e8","direction":["vertical","",""],"rowGap":[0,"",""],"rowGapVariable":["custom","",""],"kbVersion":2,"className":"t-div"} -->
<div class="wp-block-kadence-column kadence-column9_228cec-e8 kb-section-dir-vertical t-div"><div class="kt-inside-inner-col"><!-- wp:kadence/advancedheading {"uniqueID":"9_cd603f-d6","htmlTag":"span","className":"t-txt"} -->
<span class="kt-adv-heading9_cd603f-d6 wp-block-kadence-advancedheading t-txt" data-kb-block="kb-adv-heading9_cd603f-d6"><b>Notifima team</b></span>
<!-- /wp:kadence/advancedheading -->
<!-- wp:kadence/advancedheading {"uniqueID":"9_ad5dad-d1","htmlTag":"p","className":"t-p"} -->
<p class="kt-adv-heading9_ad5dad-d1 wp-block-kadence-advancedheading t-p" data-kb-block="kb-adv-heading9_ad5dad-d1">We build Notifima, the back in stock and waitlist plugin used by WooCommerce stores around the world.</p>
<!-- /wp:kadence/advancedheading --></div></div>
<!-- /wp:kadence/column --></div></div>
<!-- /wp:kadence/column -->',
);
