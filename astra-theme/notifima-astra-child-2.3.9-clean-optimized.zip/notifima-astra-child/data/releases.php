<?php
/**
 * Release notes of the original page: shown until WordPress.org / GitHub answer (inc/releases.php).
 * Static fallback data used when the remote release sources are unavailable.
 *
 * @package Notifima
 */

defined( 'ABSPATH' ) || exit;

return array(
	array( 'version' => '3.1.9', 'time' => strtotime( '3 Nov 2026' ), 'items' => array( array( 'new', 'Compatibility of WordPress 7.1.4' ), array( 'fixed', 'Frontend CSS styling issues. #2323' ), array( 'update', 'Language file' ) ) ),
	array( 'version' => '3.1.8', 'time' => strtotime( '23 Oct 2026' ), 'items' => array( array( 'new', 'Compatibility of WordPress 7.1.3' ), array( 'new', 'Compatibility of WooCommerce 11.2.1' ), array( 'fixed', 'Issue in the downloaded CSV file with subscriber details' ) ) ),
	array( 'version' => '3.1.7', 'time' => strtotime( '7 Oct 2026' ), 'items' => array( array( 'update', 'Notification Delivery settings to control how back in stock notifications are delivered to subscribers' ), array( 'update', 'Language file' ) ) ),
	array( 'version' => '3.1.6', 'time' => strtotime( '25 Sep 2026' ), 'items' => array( array( 'new', 'Compatibility of WordPress 7.1.2' ), array( 'new', 'Compatibility of WooCommerce 11.1.2' ), array( 'update', 'Improved the settings structure for better organization and usability' ), array( 'update', 'Language file' ) ) ),
	array( 'version' => '3.1.5', 'time' => strtotime( '1 Sep 2026' ), 'items' => array( array( 'fixed', 'Static lead time text not displaying correctly on the frontend product page. #2313' ), array( 'update', 'Language file' ) ) ),
	array( 'version' => '3.1.4', 'time' => strtotime( '21 Aug 2026' ), 'items' => array( array( 'new', 'Compatibility of WordPress 7.1.0' ), array( 'new', 'Compatibility of WooCommerce 11.0.1' ), array( 'fixed', 'Security vulnerability reported by WordPress Community member Shikhali Jamalzade' ) ) ),
	array( 'version' => '3.1.3', 'time' => strtotime( '4 Aug 2026' ), 'items' => array( array( 'new', 'Mobile layout for the subscription form popup' ), array( 'fixed', 'Subscription form not displayed for out-of-stock variations when other variations of the same product were in stock. #2260' ), array( 'update', 'Language file' ) ) ),
	array( 'version' => '3.1.2', 'time' => strtotime( '21 Jul 2026' ), 'items' => array( array( 'new', 'Compatibility of WordPress 7.0.2' ), array( 'new', 'Compatibility of WooCommerce 10.9.4' ), array( 'update', 'Language file' ) ) ),
	array( 'version' => '3.1.1', 'time' => strtotime( '7 Jul 2026' ), 'items' => array( array( 'fixed', 'Issue with the migration' ) ) ),
	array( 'version' => '3.1.0', 'time' => strtotime( '6 Jul 2026' ), 'items' => array( array( 'new', 'Compatibility of WordPress 7.0.0' ), array( 'new', 'Compatibility of WooCommerce 10.9.3' ), array( 'add', 'Enhanced the overall UI/UX of the settings panel' ), array( 'update', 'Language file' ) ) ),
	array( 'version' => '3.0.0', 'time' => strtotime( '8 Jul 2025' ), 'items' => array( array( 'new', 'Notifima released' ), array( 'new', 'Compatibility of WordPress 6.8.1' ), array( 'new', 'Compatibility of WooCommerce 9.9.5' ), array( 'add', 'Revamped settings panel for a more streamlined and intuitive interface' ), array( 'update', 'Enhanced structure for improved navigation and usability' ), array( 'update', 'Optimized code for better performance and stability' ), array( 'update', 'Language file' ) ) ),
	array( 'version' => '2.5.17', 'time' => strtotime( '11 Feb 2025' ), 'items' => array( array( 'new', 'Compatibility of WooCommerce 9.7.1' ), array( 'new', 'Compatibility of WooCommerce 9.6.2' ), array( 'update', 'Fatal error fixed' ) ) ),
	array( 'version' => '1.2.0', 'time' => 0, 'items' => array( array( 'add', 'New options in the plugin settings panel to customize the alert message after form submission' ), array( 'fixed', 'Fixed some issues, the plugin now works with WooCommerce 2.4+' ) ) ),
	array( 'version' => '1.1.1', 'time' => 0, 'items' => array( array( 'fixed', 'Stock alert form is displayed properly on backorder products' ), array( 'fixed', 'Alert email no longer sent automatically when backorder is enabled and in-stock is selected' ) ) ),
	array( 'version' => '1.1.0', 'time' => 0, 'items' => array( array( 'add', 'Works with WooCommerce Subscription products' ), array( 'add', 'Works with backorders even when in-stock is selected' ) ) ),
	array( 'version' => '1.0.3', 'time' => 0, 'items' => array( array( 'fixed', 'Plugin settings panel added to customize the stock alert form' ), array( 'fixed', 'Alert email is sent as soon as a product is back in stock' ), array( 'fixed', 'Plugin now works with backorders' ) ) ),
	array( 'version' => '1.0.2', 'time' => 0, 'items' => array( array( 'fixed', 'Minor bugs, compatible with the latest WooCommerce' ) ) ),
	array( 'version' => '1.0.1', 'time' => 0, 'items' => array( array( 'fixed', 'Some issues, the plugin now works with variable products' ) ) ),
	array( 'version' => '1.0.0', 'time' => 0, 'items' => array( array( 'new', 'Initial release' ) ) ),
);
