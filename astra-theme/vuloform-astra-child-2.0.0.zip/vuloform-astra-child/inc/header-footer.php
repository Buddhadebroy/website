<?php
/**
 * Header and footer, built in WordPress with Kadence blocks.
 *
 *   Content   two synced patterns (post type wp_block): "VuloForm Header" and "VuloForm Footer".
 *             They are made from patterns/site-header.php and patterns/site-footer.php when the theme is
 *             activated (or with Appearance → VuloForm → Header and footer), only if they don't exist yet.
 *             Edit them like any page: Appearance → VuloForm → Edit header / Edit footer (Kadence editor).
 *   Output    printed in place of Astra's header and footer (astra_header / astra_footer hooks) on every page.
 *             Customize → VuloForm → "Use the VuloForm header/footer" off = Astra's own header/footer.
 *   Logo      the Site Logo (VuloForm) block = Customize → Site Identity (logo, Astra retina logo); favicon = Site Icon.
 *   Menu      the Site Menu (VuloForm) block = Appearance → Menus → "VuloForm header".
 *
 * @package VuloForm
 */

defined( 'ABSPATH' ) || exit;

/** The two parts: option that stores the synced pattern ID, its title and the pattern file it starts from. */
function vf_hf_parts() {
	return array(
		'header' => array( 'option' => 'vf_header_block', 'title' => __( 'VuloForm Header', 'vuloform' ), 'pattern' => 'site-header' ),
		'footer' => array( 'option' => 'vf_footer_block', 'title' => __( 'VuloForm Footer', 'vuloform' ), 'pattern' => 'site-footer' ),
	);
}

/** Block markup of a generated pattern file (patterns/*.php echo their markup; links are resolved here). */
function vf_pattern_markup( $slug ) {
	$file = VF_DIR . '/patterns/' . sanitize_file_name( $slug ) . '.php';
	if ( ! file_exists( $file ) ) {
		return '';
	}
	ob_start();
	include $file;
	return trim( ob_get_clean() );
}

/** The synced pattern post of a part, or null when it was deleted / never made. */
function vf_hf_post( $part ) {
	$p    = vf_hf_parts()[ $part ];
	$id   = (int) get_option( $p['option'] );
	$post = $id ? get_post( $id ) : null;
	return ( $post && 'wp_block' === $post->post_type && 'trash' !== $post->post_status ) ? $post : null;
}

/**
 * Make the synced pattern of a part from its pattern file.
 * $reset = true puts the original back into the existing one (WordPress keeps the old version as a revision).
 * Returns the post ID (0 on failure).
 */
function vf_hf_create( $part, $reset = false ) {
	$p    = vf_hf_parts()[ $part ];
	$post = vf_hf_post( $part );
	if ( $post && ! $reset ) {
		return $post->ID;
	}
	$content = vf_pattern_markup( $p['pattern'] );
	if ( '' === $content ) {
		return 0;
	}
	$data = array(
		'post_type'    => 'wp_block',
		'post_status'  => 'publish',
		'post_title'   => $p['title'],
		'post_content' => wp_slash( $content ),
	);
	if ( $post ) {
		$data['ID'] = $post->ID;
		$id         = wp_update_post( $data, true );
	} else {
		$id = wp_insert_post( $data, true );
	}
	if ( is_wp_error( $id ) || ! $id ) {
		return 0;
	}
	update_option( $p['option'], (int) $id, false );
	return (int) $id;
}

/** Edit link of a part (block editor with Kadence). */
function vf_hf_edit_url( $part ) {
	$post = vf_hf_post( $part );
	return $post ? admin_url( 'post.php?post=' . $post->ID . '&action=edit' ) : '';
}

/** HTML of a part: the synced pattern, or the pattern file when it doesn't exist (yet). */
function vf_hf_render( $part ) {
	$post    = vf_hf_post( $part );
	$content = $post && 'publish' === $post->post_status ? $post->post_content : vf_pattern_markup( vf_hf_parts()[ $part ]['pattern'] );
	return do_shortcode( do_blocks( $content ) );
}

/** Theme activated: make the header and footer (only when missing) and fill Site Identity when it is empty. */
add_action(
	'after_switch_theme',
	function () {
		vf_hf_create( 'header' );
		vf_hf_create( 'footer' );
		vf_import_identity();
	}
);

/**
 * Logo and favicon: Customize → Site Identity. On activation, when no logo / site icon is set yet,
 * the VuloForm icon is added to the Media Library and used for both (change them any time in Site Identity).
 */
function vf_import_identity() {
	if ( ! function_exists( 'media_handle_sideload' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
	}
	$add = function ( $file, $title ) {
		$tmp = wp_tempnam( $file );
		copy( VF_DIR . '/assets/img/' . $file, $tmp );
		$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), 0, $title );
		if ( is_wp_error( $id ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return 0;
		}
		return (int) $id;
	};
	if ( ! get_theme_mod( 'custom_logo' ) ) {
		$id = $add( 'brand-icon.png', 'VuloForm logo' );
		if ( $id ) {
			set_theme_mod( 'custom_logo', $id );
		}
	}
	if ( ! get_option( 'site_icon' ) ) {
		$id = $add( 'site-icon.png', 'VuloForm site icon' );
		if ( $id ) {
			update_option( 'site_icon', $id );
		}
	}
}

/** Print ours in place of Astra's header / footer. */
add_action(
	'wp',
	function () {
		if ( vf_opt( 'vf_use_header' ) ) {
			remove_all_actions( 'astra_header' );
			add_action( 'astra_header', function () { echo vf_hf_render( 'header' ); } ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( vf_opt( 'vf_use_footer' ) ) {
			remove_all_actions( 'astra_footer' );
			add_action( 'astra_footer', function () { echo vf_hf_render( 'footer' ); } ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}
);

/** Header links: the menu assigned to a location (top level items), else vf_nav_links(). Returns [ [href, label] ]. */
function vf_menu_links( $location = 'vf_header' ) {
	$loc = get_nav_menu_locations();
	if ( ! empty( $loc[ $location ] ) ) {
		$items = wp_get_nav_menu_items( $loc[ $location ] );
		if ( $items ) {
			$out = array();
			foreach ( $items as $it ) {
				if ( ! $it->menu_item_parent ) {
					$out[] = array( $it->url, $it->title );
				}
			}
			return $out;
		}
	}
	return vf_nav_links();
}

/** Register the two blocks used by the header and footer. */
add_action(
	'init',
	function () {
		wp_register_script( 'vf-site-blocks-editor', VF_URI . '/blocks/site-editor.js', array( 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-server-side-render' ), vf_ver( 'blocks/site-editor.js' ), true );
		register_block_type( VF_DIR . '/blocks/site-logo' );
		register_block_type( VF_DIR . '/blocks/site-menu' );
	},
	20
);
