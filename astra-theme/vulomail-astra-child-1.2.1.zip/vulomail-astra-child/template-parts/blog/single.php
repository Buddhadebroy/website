<?php
/**
 * Single post, like the original /blog/[slug]: breadcrumb, category, title, meta, "On this page",
 * "The short answer" (the post excerpt), the Kadence body, FAQ, "Keep reading" and the banner.
 *
 * @package vulomail
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) {
	the_post();
	$p            = vm_post_array( get_the_ID(), true );
	$p['content'] = apply_filters( 'the_content', get_the_content() ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals
	$cta          = vm_render_pattern( 'blog-cta' );
	echo '<main id="content" class="vm-main vm:relative">';
	echo vm_blog_single_html( $p, vm_h2_index( $p['content'] ), $cta ); // phpcs:ignore
	echo '</main>';
}
get_footer();
