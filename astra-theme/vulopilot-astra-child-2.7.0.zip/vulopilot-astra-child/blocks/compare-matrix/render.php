<?php

/**
 * Plan comparison block – front-end markup (mirrors components/CompareMatrix.tsx).
 *
 * @var array $attributes
 * @package VuloPilot
 */

defined('ABSPATH') || exit;

$a      = $attributes;
$cols   = 'grid-cols-[1fr_64px_84px] sm:grid-cols-[1fr_100px_130px]';
$groups = array();
foreach ((array) $a['groups'] as $i => $g) {
	$groups[] = array(
		'title' => $g['title'] ?? '',
		'icon'  => $g['icon'] ?? 'sparkles',
		'free'  => vp_lines($g['free'] ?? ''),
		'paid'  => vp_lines($g['paid'] ?? ''),
		'link'  => array($g['linkText'] ?? '', $g['linkUrl'] ?? ''),
		'open'  => ! empty($g['open']),
	);
}
$free_n = array_sum(array_map(function ($g) {
	return count($g['free']);
}, $groups));
$paid_n = array_sum(array_map(function ($g) {
	return count($g['paid']);
}, $groups));
$all_open = $groups && count(array_filter($groups, function ($g) {
	return $g['open'];
})) === count($groups);
$yes  = '<span class="mx-auto grid h-6 w-6 place-items-center rounded-full bg-sage-soft text-sage">' . vp_icon('check', 13, '', 3) . '</span>';
$solid = '<span class="mx-auto grid h-6 w-6 place-items-center rounded-full bg-sage text-white">' . vp_icon('check', 13, '', 3) . '</span>';
$no   = vp_icon('minus', 15, 'mx-auto text-line');
$mw   = (int) $a['maxWidth'] ? 'max-width:' . (int) $a['maxWidth'] . 'px' : '';
$uid  = wp_unique_id('vp-cm-');
?>
<div <?php echo vp_block_wrapper($a, 'vp-cm'); // phpcs:ignore 
		?> data-vp-cm>
	<section class="px-5 py-14">
		<?php if ($a['showHeading']) : ?>
			<div class="vp-reveal text-center">
				<?php if ($a['eyebrow']) : ?>
					<div class="inline-flex items-center gap-2 rounded-sm border border-line bg-surface/70 px-3 py-1 font-mono text-[11px] uppercase tracking-[0.14em] text-sage"><span class="h-1.5 w-1.5 rounded-full bg-apricot"></span><?php echo esc_html($a['eyebrow']); ?></div>
				<?php endif; ?>
				<h2 class="mt-5 text-4xl font-semibold leading-[1.08] tracking-tight sm:text-5xl" <?php echo (int) $a['titleSize'] ? ' style="font-size:' . (int) $a['titleSize'] . 'px"' : ''; ?>><?php echo wp_kses_post($a['title']); ?> <span class="text-sage"><?php echo wp_kses_post($a['titleAccent']); ?></span></h2>
				<?php if ($a['subtitle']) : ?>
					<p class="mt-3 text-muted"><?php echo esc_html(strtr($a['subtitle'], array('{free}' => $free_n, '{paid}' => $paid_n))); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="card <?php echo $a['showHeading'] ? 'mt-8' : ''; ?> overflow-hidden">
			<div class="grid <?php echo esc_attr($cols); ?> items-center border-b border-line bg-bg/60 px-4 py-4 sm:px-6">
				<div class="flex items-center gap-4 text-xs">
					<label class="flex cursor-pointer items-center gap-2 font-semibold">
						<span class="relative inline-block h-5 w-9"><input type="checkbox" class="peer sr-only" data-vp-cm-only /><span class="absolute inset-0 rounded-sm bg-line transition peer-checked:bg-sage"></span><span class="absolute left-0.5 top-0.5 h-4 w-4 rounded-sm bg-white shadow transition peer-checked:translate-x-4"></span></span>
						<?php echo esc_html($a['toggleLabel']); ?>
					</label>
					<button type="button" class="font-semibold text-sage hover:underline" data-vp-cm-all data-expand="<?php echo esc_attr($a['expandLabel']); ?>" data-collapse="<?php echo esc_attr($a['collapseLabel']); ?>"><?php echo esc_html($all_open ? $a['collapseLabel'] : $a['expandLabel']); ?></button>
				</div>
				<div class="text-center">
					<div class="text-sm font-semibold"><?php echo esc_html($a['freeLabel']); ?></div>
					<div class="text-[11px] text-muted"><?php echo esc_html($a['freePrice']); ?></div>
				</div>
				<div class="text-center">
					<div class="rounded-sm bg-sage px-3 py-1 text-sm font-semibold text-white"><?php echo esc_html($a['paidLabel']); ?></div>
					<div class="mt-1 text-[11px] text-muted"><?php echo esc_html($a['paidPrice']); ?></div>
				</div>
			</div>

			<?php if (! empty($a['limits'])) : ?>
				<div class="grid gap-3 border-b border-line px-4 py-4 sm:grid-cols-2 sm:px-6">
					<?php foreach ((array) $a['limits'] as $l) : ?>
						<div class="flex items-center justify-between rounded-sm bg-bg px-4 py-3 text-sm"><span class="flex items-center gap-2 font-medium"><?php echo vp_icon($l['icon'] ?? 'server', 15, 'text-sage'); // phpcs:ignore 
																																							?><?php echo esc_html($l['label'] ?? ''); ?></span><span><span class="text-muted"><?php echo esc_html($l['free'] ?? ''); ?></span> <b class="text-sage"><?php echo esc_html($l['paid'] ?? ''); ?></b></span></div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php foreach ($groups as $i => $g) : $bid = $uid . '-' . $i; ?>
				<div class="border-b border-line last:border-b-0" data-vp-cm-group data-has-paid="<?php echo $g['paid'] ? '1' : '0'; ?>">
					<button type="button" aria-expanded="<?php echo $g['open'] ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr($bid); ?>" class="flex w-full items-center gap-3 px-4 py-4 text-left transition-colors hover:bg-sage-soft/30 sm:px-6" data-vp-cm-toggle>
						<span class="grid h-9 w-9 shrink-0 place-items-center rounded-sm bg-sage-soft text-sage"><?php echo vp_icon($g['icon'], 17); // phpcs:ignore 
																													?></span>
						<span class="min-w-0 flex-1"><span class="block font-semibold leading-tight"><?php echo esc_html($g['title']); ?></span><span class="text-xs text-muted"><?php echo count($g['free']) . ' ' . esc_html($a['freeCountLabel']); ?><?php if ($g['paid']) : ?> · <span class="font-semibold text-flare"><?php echo count($g['paid']) . ' ' . esc_html($a['paidCountLabel']); ?></span><?php endif; ?></span></span>
						<?php echo vp_icon('chevron-down', 18, 'vp-cm-chev shrink-0 text-muted transition-transform' . ($g['open'] ? ' rotate-180' : '')); // phpcs:ignore 
						?>
					</button>
					<div id="<?php echo esc_attr($bid); ?>" class="overflow-hidden" data-vp-cm-body<?php echo $g['open'] ? '' : ' style="height:0;opacity:0" hidden'; ?>>
						<?php foreach ($g['free'] as $x) : ?>
							<div class="vp-cm-free grid <?php echo esc_attr($cols); ?> items-center px-4 py-2.5 text-sm transition-colors hover:bg-bg/70 sm:px-6"><span class="pr-4"><?php echo esc_html($x); ?></span><?php echo $yes . $solid; // phpcs:ignore 
																																																							?></div>
						<?php endforeach; ?>
						<?php foreach ($g['paid'] as $x) : ?>
							<div class="grid <?php echo esc_attr($cols); ?> items-center bg-flare/[.04] px-4 py-2.5 text-sm transition-colors hover:bg-flare/[.08] sm:px-6"><span class="pr-4"><?php echo esc_html($x); ?><span class="ml-2 rounded-sm bg-flare/15 px-2 py-0.5 text-[10px] font-bold text-flare"><?php echo esc_html($a['paidTag']); ?></span></span><?php echo $no . $solid; // phpcs:ignore 
																																																																																											?></div>
						<?php endforeach; ?>
						<?php if ($g['link'][0] && $g['link'][1]) : ?>
							<div class="px-4 pb-4 pt-1 sm:px-6"><a href="<?php echo esc_url(vp_url($g['link'][1])); ?>" class="text-xs font-semibold text-sage hover:underline"><?php echo esc_html($g['link'][0]); ?></a></div>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</section>
</div>