<?php
/**
 * Product Tour block. Uses template-parts/home/product-tour.php with the block's groups and screens.
 *
 * @var array $attributes
 * @package VuloPilot
 */

defined( 'ABSPATH' ) || exit;

$a      = $attributes;
$shots  = vp_screens();
$groups = array();
foreach ( (array) ( $a['groups'] ?? array() ) as $g ) {
	$screens = array();
	foreach ( (array) ( $g['screens'] ?? array() ) as $sc ) {
		$key = sanitize_key( $sc['screen'] ?? '' );
		$src = esc_url_raw( $sc['image'] ?? '' );
		$w   = 1600;
		$h   = 900;
		if ( $src && ! empty( $sc['imageId'] ) ) {
			$meta = wp_get_attachment_metadata( (int) $sc['imageId'] );
			if ( ! empty( $meta['width'] ) ) {
				$w = (int) $meta['width'];
				$h = (int) $meta['height'];
			}
		} elseif ( ! $src && isset( $shots[ $key ] ) ) {
			// No own image: use the screenshot picked in Customize → VuloPilot screenshots.
			$src = $shots[ $key ]['src'];
			$w   = $shots[ $key ]['w'];
			$h   = $shots[ $key ]['h'];
		}
		$hs = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $sc['hotspots'] ?? '' ) ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line ) );
			if ( count( $p ) < 2 ) {
				continue;
			}
			$xy   = array_map( 'floatval', array_pad( preg_split( '/[\s,;]+/', $p[0], -1, PREG_SPLIT_NO_EMPTY ), 2, 50 ) );
			$hs[] = array( min( 97, max( 3, $xy[0] ) ), min( 97, max( 3, $xy[1] ) ), $p[1], $p[2] ?? '' );
		}
		$where = (string) ( $sc['where'] ?? '' );
		$screens[] = array(
			'title'    => (string) ( $sc['title'] ?? '' ),
			'where'    => preg_replace( '#^wp-admin / VuloPilot / #', '', $where ),
			'src'      => $src,
			'w'        => $w,
			'h'        => $h,
			'alt'      => (string) ( $sc['alt'] ?? '' ),
			'hotspots' => array_slice( $hs, 0, 6 ),
		);
	}
	$groups[] = array(
		'icon'    => vp_safe_icon( $g['icon'] ?? '', 'sparkles' ),
		'title'   => (string) ( $g['title'] ?? '' ),
		'hint'    => (string) ( $g['hint'] ?? '' ),
		'screens' => $screens,
	);
}
$title = esc_html( $a['title'] ?? '' );
if ( '' !== trim( (string) ( $a['titleAccent'] ?? '' ) ) ) {
	$title .= ' <span class="text-sage">' . esc_html( $a['titleAccent'] ) . '</span>';
}

echo '<div ' . vp_block_wrapper( $a, 'vp-product-tour-block' ) . '>'; // phpcs:ignore
get_template_part(
	'template-parts/home/product-tour',
	null,
	array(
		'graphic_only' => empty( $a['wrap'] ),
		'show_heading' => ! empty( $a['showHeading'] ),
		'id'           => sanitize_html_class( $a['sectionId'] ?? '' ),
		'eyebrow'      => (string) ( $a['eyebrow'] ?? '' ),
		'title'        => $title,
		'intro'        => (string) ( $a['intro'] ?? '' ),
		'interval'     => max( 1500, (int) ( $a['interval'] ?? 4200 ) ),
		'groups'       => $groups,
	)
);
echo '</div>';
