<?php
/**
 * Interactive checklist block – front-end markup (mirrors components/Checklist.tsx).
 *
 * @var array $attributes
 * @package VuloPilot
 */

defined( 'ABSPATH' ) || exit;

$a      = $attributes;
$groups = array();
foreach ( (array) $a['groups'] as $g ) {
	$groups[] = array( 'title' => $g['title'] ?? '', 'items' => vp_lines( $g['items'] ?? '' ) );
}
$total = array_sum( array_map( function ( $g ) { return count( $g['items'] ); }, $groups ) );
$size  = max( 80, (int) $a['ringSize'] );
$r     = $size / 2 - 8;
$c     = 2 * M_PI * $r;
$id    = sanitize_title( $a['storageId'] ? $a['storageId'] : 'checklist' );
$mw    = (int) $a['maxWidth'] ? 'max-width:' . (int) $a['maxWidth'] . 'px' : '';
$check = vp_icon( 'check', 14 );
?>
<div <?php echo vp_block_wrapper( $a, 'vp-chk' ); // phpcs:ignore ?> data-vp-chk="<?php echo esc_attr( $id ); ?>" data-count="<?php echo esc_attr( $a['countText'] ); ?>" data-progress="<?php echo esc_attr( $a['progressText'] ); ?>" data-complete="<?php echo esc_attr( $a['completeText'] ); ?>" data-title="<?php echo esc_attr( wp_strip_all_tags( $a['heading'] ? $a['heading'] : get_the_title() ) ); ?>">
<section class="px-5 py-10">
	<div class="mx-auto max-w-5xl" style="<?php echo esc_attr( $mw ); ?>">
		<?php if ( $a['heading'] ) : ?>
		<div class="vp-reveal"><h2 class="mt-4 font-display text-3xl leading-tight sm:text-4xl"><?php echo wp_kses_post( $a['heading'] ); ?></h2></div>
		<?php endif; ?>
		<div class="<?php echo $a['heading'] ? 'mt-8' : ''; ?>">
			<div class="grid gap-8 lg:grid-cols-[280px_1fr]">
				<div class="card h-fit p-6 text-center <?php echo $a['sticky'] ? 'lg:sticky lg:top-28' : ''; ?>">
					<div class="mx-auto w-fit">
						<div class="relative" style="width:<?php echo (int) $size; ?>px;height:<?php echo (int) $size; ?>px">
							<svg width="<?php echo (int) $size; ?>" height="<?php echo (int) $size; ?>" class="-rotate-90" aria-hidden="true">
								<circle cx="<?php echo $size / 2; ?>" cy="<?php echo $size / 2; ?>" r="<?php echo esc_attr( $r ); ?>" fill="none" stroke="var(--line)" stroke-width="8"></circle>
								<circle data-vp-chk-ring cx="<?php echo $size / 2; ?>" cy="<?php echo $size / 2; ?>" r="<?php echo esc_attr( $r ); ?>" fill="none" stroke="var(--sage)" stroke-width="8" stroke-linecap="round" stroke-dasharray="<?php echo esc_attr( $c ); ?>" stroke-dashoffset="<?php echo esc_attr( $c ); ?>"></circle>
							</svg>
							<div class="absolute inset-0 grid place-items-center text-center"><div>
								<div class="font-display text-3xl leading-none" data-vp-chk-pct>0</div>
								<?php if ( $a['ringLabel'] ) : ?><div class="mt-1 text-[10px] uppercase tracking-widest text-muted"><?php echo esc_html( $a['ringLabel'] ); ?></div><?php endif; ?>
							</div></div>
						</div>
					</div>
					<p class="mt-4 text-sm text-muted" data-vp-chk-count><?php echo esc_html( strtr( $a['countText'], array( '{done}' => 0, '{total}' => $total ) ) ); ?></p>
					<p class="mt-1 font-display text-lg" data-vp-chk-msg><?php echo esc_html( $a['progressText'] ); ?></p>
					<?php if ( ! empty( $a['ctaTitle'] ) || ! empty( $a['ctaText'] ) ) : ?>
					<div class="mt-6 rounded-sm border border-sage/30 bg-sage-soft/60 p-5 text-left">
						<?php if ( ! empty( $a['ctaKicker'] ) ) : ?>
						<p class="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-sage"><?php echo vp_icon( 'zap', 13 ); // phpcs:ignore ?><?php echo esc_html( $a['ctaKicker'] ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $a['ctaTitle'] ) ) : ?>
						<p class="mt-2 font-display text-lg leading-snug"><?php echo esc_html( $a['ctaTitle'] ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $a['ctaBody'] ) ) : ?>
						<p class="mt-2 text-sm leading-relaxed text-muted"><?php echo esc_html( $a['ctaBody'] ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $a['ctaText'] ) ) : ?>
						<a href="<?php echo esc_url( vp_url( $a['ctaUrl'] ? $a['ctaUrl'] : '/#pricing' ) ); ?>" class="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-sm bg-ink px-4 py-2.5 text-sm font-medium text-bg transition hover:bg-sage"><?php echo esc_html( $a['ctaText'] ); ?><?php echo vp_icon( 'arrow-right', 15 ); // phpcs:ignore ?></a>
						<?php endif; ?>
						<?php if ( ! empty( $a['ctaNote'] ) ) : ?>
						<p class="mt-2 text-center text-xs text-muted"><?php echo esc_html( $a['ctaNote'] ); ?></p>
						<?php endif; ?>
					</div>
					<?php endif; ?>
					<?php if ( ! empty( $a['downloadText'] ) ) : ?>
					<div><button type="button" class="mt-4 inline-flex items-center gap-1.5 text-sm text-muted underline-offset-4 transition hover:text-ink hover:underline" data-vp-chk-download><?php echo vp_icon( 'download', 14 ); // phpcs:ignore ?><?php echo esc_html( $a['downloadText'] ); ?></button></div>
					<?php endif; ?>
					<?php if ( $a['resetText'] ) : ?>
					<button type="button" class="mt-4 inline-flex items-center gap-1.5 text-sm text-muted hover:text-ink" data-vp-chk-reset><?php echo vp_icon( 'rotate-ccw', 14 ); // phpcs:ignore ?><?php echo esc_html( $a['resetText'] ); ?></button>
					<?php endif; ?>
				</div>
				<div class="space-y-8">
					<?php foreach ( $groups as $g ) : ?>
					<div data-vp-chk-group="<?php echo esc_attr( $g['title'] ); ?>">
						<?php if ( $g['title'] ) : ?><h3 class="mb-3 font-mono text-xs uppercase tracking-widest text-sage"><?php echo esc_html( $g['title'] ); ?></h3><?php endif; ?>
						<div class="space-y-2">
							<?php foreach ( $g['items'] as $it ) : ?>
							<button type="button" aria-pressed="false" data-vp-chk-item="<?php echo esc_attr( $it ); ?>" class="vp-chk-item flex w-full items-center gap-4 rounded-sm border px-5 py-4 text-left transition border-line bg-surface hover:border-ink/30">
								<span class="vp-chk-box grid h-6 w-6 shrink-0 place-items-center rounded-full border transition border-line"><span class="vp-chk-tick" hidden><?php echo $check; // phpcs:ignore ?></span></span>
								<span class="vp-chk-text"><?php echo esc_html( $it ); ?></span>
							</button>
							<?php endforeach; ?>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php
if ( $a['howToSchema'] && $total ) {
	$steps = array();
	foreach ( $groups as $g ) {
		foreach ( $g['items'] as $it ) {
			$steps[] = array( '@type' => 'HowToStep', 'text' => ( $g['title'] ? $g['title'] . ': ' : '' ) . $it );
		}
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'HowTo', 'name' => wp_strip_all_tags( $a['heading'] ? $a['heading'] : get_the_title() ), 'step' => $steps ) ) . '</script>';
}
?>
</div>
