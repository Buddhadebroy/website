<?php
/**
 * How It Works Stepper block. Uses template-parts/home/how.php with the block's content.
 *
 * @var array $attributes
 * @package VuloPilot
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$steps = array();
foreach ( (array) ( $a['steps'] ?? array() ) as $s ) {
	$steps[] = array(
		vp_safe_icon( $s['icon'] ?? '', 'sparkles' ),
		(string) ( $s['title'] ?? '' ),
		(string) ( $s['desc'] ?? '' ),
		vp_lines( $s['points'] ?? '' ),
		sanitize_key( $s['graphic'] ?? '' ),
		esc_url_raw( $s['image'] ?? '' ),
		(string) ( $s['imageAlt'] ?? '' ),
	);
}
$title = esc_html( $a['title'] ?? '' );
if ( '' !== trim( (string) ( $a['titleAccent'] ?? '' ) ) ) {
	$title .= ' <span class="text-sage">' . esc_html( $a['titleAccent'] ) . '</span>';
}

echo '<div ' . vp_block_wrapper( $a, 'vp-how-stepper-block' ) . '>'; // phpcs:ignore
get_template_part(
	'template-parts/home/how',
	null,
	array(
		'graphic_only' => empty( $a['wrap'] ),
		'show_heading' => ! empty( $a['showHeading'] ),
		'id'           => sanitize_html_class( $a['sectionId'] ?? '' ),
		'eyebrow'      => (string) ( $a['eyebrow'] ?? '' ),
		'title'        => $title,
		'intro'        => (string) ( $a['intro'] ?? '' ),
		'interval'     => max( 1500, (int) ( $a['interval'] ?? 5600 ) ),
		'status'       => array( 'play' => (string) ( $a['playLabel'] ?? '' ), 'pause' => (string) ( $a['pauseLabel'] ?? '' ) ),
		'steps'        => $steps ? $steps : null,
	)
);
echo '</div>';
