<?php
/**
 * Mega menu block.
 *
 * @var array $attributes
 * @package VuloPilot
 */

defined( 'ABSPATH' ) || exit;

$a = $attributes;
?>
<div <?php echo vp_block_wrapper( $a, 'vp-mega-menu-block' ); // phpcs:ignore ?>>
	<?php echo vp_render_header( array( 'menu' => $a['menu'] ? (int) $a['menu'] : null, 'fixed' => (bool) $a['fixed'], 'cta' => (bool) $a['showCta'] ) ); // phpcs:ignore ?>
</div>
