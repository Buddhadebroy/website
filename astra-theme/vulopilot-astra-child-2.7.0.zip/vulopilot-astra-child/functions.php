<?php
/**
 * VuloPilot Astra Child – bootstrap.
 *
 *   inc/       site code: setup, header, footer, popup, blocks, admin screen
 *   graphic/   everything for the animated graphics (see graphic/graphic.php)
 *   style.css  the site's custom CSS (table of contents at the top)
 *
 * @package VuloPilot
 */

defined( 'ABSPATH' ) || exit;

define( 'VP_VERSION', '2.7.0' );
define( 'VP_DIR', get_stylesheet_directory() );
define( 'VP_URI', get_stylesheet_directory_uri() );

// Helpers and data.
require VP_DIR . '/inc/helpers.php';
require VP_DIR . '/inc/content-data.php';
require VP_DIR . '/inc/template-helpers.php';
require VP_DIR . '/inc/menu-data.php';

// Theme setup, options and assets.
require VP_DIR . '/inc/customizer.php';
require VP_DIR . '/inc/setup.php';

// Site parts.
require VP_DIR . '/inc/header.php';
require VP_DIR . '/inc/footer.php';
require VP_DIR . '/inc/consult.php';
require VP_DIR . '/inc/shortcodes.php';
require VP_DIR . '/inc/blocks.php';
require VP_DIR . '/inc/admin.php';

// Animated graphics.
require VP_DIR . '/graphic/graphic.php';
