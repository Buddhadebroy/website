<?php
/**
 * Mega menu + footer data.
 *
 * The header and footer read the menus assigned to the "VuloPilot header" and "VuloPilot footer"
 * locations (Appearance → Menus). With no menu assigned they show the same links as the Next.js site.
 *
 * Header menu structure (Appearance → Menus):
 *   Level 1  item without children .......... plain link (How it works, Pricing, About)
 *   Level 1  item with children ............. dropdown (Product, Solutions, Compare, Learn)
 *   Level 2  normal item .................... category in the left rail
 *              Navigation Label = title, Description = hint, URL = "All …" link,
 *              Title Attribute = "All …" link text, CSS class vp-icon-NAME = rail icon
 *   Level 3  item ........................... link inside the category
 *              Description = small grey line, CSS class vp-icon-NAME = icon (else picked from the URL)
 *   Level 2  item with CSS class vp-promo ... promo card on the right
 *              Navigation Label = heading, Title Attribute = small kicker, URL = button link,
 *              Description = "body text || button text", CSS class vp-icon-NAME = icon
 *   Level 2  item with CSS class vp-foot .... small link at the bottom right of the panel
 *
 * Footer menu: level 1 = column title, level 2 = links. Add CSS class vp-row-2 to a column
 * to put it in the second row (the "Compare" columns on the original site).
 *
 * @package VuloPilot
 */

defined( 'ABSPATH' ) || exit;

/** Default header menu, identical to components/Nav.tsx. */
function vp_default_header_menu() {
	$site  = vp_data( 'site' );
	$links = $site['links'];
	$desc  = array();
	foreach ( $site['features'] as $f ) {
		$desc[ $f['slug'] ] = $f['tagline'];
	}
	$feat = array_map(
		function ( $i ) use ( $desc ) {
			$i['desc'] = $desc[ vp_slug_of( $i['href'] ) ] ?? '';
			return $i;
		},
		$links['features']
	);
	$g = function ( $name ) use ( $links ) {
		foreach ( $links['compare'] as $grp ) {
			if ( $grp['group'] === $name ) {
				return $grp['items'];
			}
		}
		return array();
	};
	$cat = function ( $id, $title, $hint, $icon, $items, $all_label, $all_href ) {
		return array(
			'id'    => $id,
			'title' => $title,
			'hint'  => $hint,
			'icon'  => $icon,
			'items' => $items,
			'all'   => array( 'label' => $all_label, 'href' => $all_href ),
		);
	};
	$promo = function ( $icon, $kicker, $title, $body, $cta, $href ) {
		return compact( 'icon', 'kicker', 'title', 'body', 'cta', 'href' );
	};
	return array(
		array(
			'type'  => 'mega', 'id' => 'product', 'label' => 'Product',
			'promo' => $promo( 'sparkles', 'Free + Pro', 'See what each plan includes', 'Area by area, nothing hidden.', 'Compare plans', '/pricing/' ),
			'foot'  => array( 'label' => 'See how it works', 'href' => '/how-it-works/' ),
			'cats'  => array( $cat( 'features', 'Features', 'Eight areas, one plugin', 'sparkles', $feat, 'All features', '/features/' ) ),
		),
		array(
			'type'  => 'mega', 'id' => 'solutions', 'label' => 'Solutions',
			'promo' => $promo( 'zap', 'Ready to level up?', 'SuperPower your website', 'Start free. Upgrade when you want AI to act.', 'See plans', '/#pricing' ),
			'foot'  => array( 'label' => 'Not sure? Compare plans', 'href' => '/pricing/' ),
			'cats'  => array(
				$cat( 'goal', 'Solutions', 'What you want to achieve', 'target', $links['solutions'], 'All solutions', '/solutions/' ),
				$cat( 'role', 'For', 'Built for your role', 'users', $links['audiences'], 'All roles', '/for/' ),
				$cat( 'job', 'Use cases', 'Jobs to get done', 'wrench', $links['useCases'], 'All use cases', '/use-cases/' ),
				$cat( 'pain', 'Problems', 'Start from the pain', 'alert-triangle', $links['problems'], 'All problems', '/problems/' ),
			),
		),
		array(
			'type'  => 'mega', 'id' => 'compare', 'label' => 'Compare',
			'promo' => $promo( 'puzzle', 'Honest comparisons', 'Where each tool fits', 'Strengths on both sides, and how to combine them.', 'How it works', '/how-it-works/' ),
			'foot'  => array( 'label' => 'Honest, both-sides comparisons', 'href' => '/compare/' ),
			'cats'  => array(
				$cat( 'wp', 'SEO plugins', 'On-page SEO for WordPress', 'puzzle', $g( 'SEO & WordPress' ), 'All comparisons', '/compare/' ),
				$cat( 'opt', 'Optimization', 'Speed, security, crawling', 'zap', $g( 'Website Optimization' ), 'All comparisons', '/compare/' ),
				$cat( 'plat', 'SEO platforms', 'Research and content suites', 'bar-chart3', $g( 'SEO Platforms' ), 'All comparisons', '/compare/' ),
				$cat( 'goog', 'Google tools', 'Free tools from Google', 'search', $g( 'Google Tools' ), 'All comparisons', '/compare/' ),
				$cat( 'gen', 'General', 'Approaches, not brands', 'clipboard-list', $g( 'General' ), 'All comparisons', '/compare/' ),
			),
		),
		array(
			'type'  => 'mega', 'id' => 'learn', 'label' => 'Learn',
			'promo' => $promo( 'list-checks', 'Free', 'Interactive checklists', 'Tick items off. Progress saves in your browser.', 'Open a checklist', '/checklist/seo-checklist/' ),
			'foot'  => array( 'label' => 'Install and first scan', 'href' => '/docs/' ),
			'cats'  => array(
				$cat( 'guides', 'Guides', 'Practical, plain-language', 'book-open', $links['guides'], 'All guides', '/guides/' ),
				$cat( 'lists', 'Checklists', 'Interactive and free', 'list-checks', $links['resources'], 'All checklists', '/checklist/' ),
				$cat(
					'more', 'Blog & Docs', 'Articles and setup', 'file-text',
					array(
						array( 'label' => 'Blog', 'href' => '/blog/', 'desc' => 'Guides and articles' ),
						array( 'label' => 'Docs', 'href' => '/docs/', 'desc' => 'Install and get started' ),
						array( 'label' => 'About us', 'href' => '/about/', 'desc' => 'Who builds VuloPilot' ),
						array( 'label' => 'Brand', 'href' => '/brand/', 'desc' => 'Logo, colors and assets' ),
					),
					'How it works', '/how-it-works/'
				),
			),
		),
		array( 'type' => 'link', 'label' => 'Pricing', 'href' => '/pricing/' ),
	);
}

/** Default footer columns, identical to components/Footer.tsx. */
function vp_default_footer_menu() {
	$l    = vp_data( 'site' )['links'];
	$cols = array(
		array( 'title' => 'Product', 'row' => 1, 'items' => array_merge( array( array( 'label' => 'How it works', 'href' => '/how-it-works/' ) ), $l['features'], array( array( 'label' => 'Pricing', 'href' => '/pricing/' ) ) ) ),
		array( 'title' => 'Solutions', 'row' => 1, 'items' => $l['solutions'] ),
		array( 'title' => 'For & use cases', 'row' => 1, 'items' => array_merge( $l['audiences'], array_slice( $l['useCases'], 0, 5 ) ) ),
		array( 'title' => 'Problems', 'row' => 1, 'items' => $l['problems'] ),
		array( 'title' => 'Learn', 'row' => 1, 'items' => array_merge( array_slice( $l['guides'], 0, 8 ), array( array( 'label' => 'Blog', 'href' => '/blog/' ), array( 'label' => 'Docs', 'href' => '/docs/' ), array( 'label' => 'About', 'href' => '/about/' ) ) ) ),
	);
	foreach ( $l['compare'] as $grp ) {
		$cols[] = array( 'title' => 'Compare · ' . $grp['group'], 'row' => 2, 'items' => $grp['items'] );
	}
	return $cols;
}

/** Nested tree of a WP nav menu. */
function vp_menu_tree( $menu ) {
	$items = $menu ? wp_get_nav_menu_items( $menu ) : array();
	if ( ! $items ) {
		return array();
	}
	$by = array();
	foreach ( $items as $it ) {
		$it->vp_children        = array();
		$by[ (int) $it->ID ] = $it;
	}
	$tree = array();
	foreach ( $by as $it ) {
		$p = (int) $it->menu_item_parent;
		if ( $p && isset( $by[ $p ] ) ) {
			$by[ $p ]->vp_children[] = $it;
		} else {
			$tree[] = $it;
		}
	}
	return $tree;
}

/** Menu object assigned to a location, or null. */
function vp_menu_at( $location ) {
	$locs = get_nav_menu_locations();
	return ! empty( $locs[ $location ] ) ? wp_get_nav_menu_object( $locs[ $location ] ) : null;
}

/** Header menu (from Appearance → Menus, or the defaults). $menu may be a menu id/slug to force one. */
function vp_header_menu( $menu = null ) {
	$menu = $menu ? wp_get_nav_menu_object( $menu ) : vp_menu_at( 'vp_header' );
	$tree = $menu ? vp_menu_tree( $menu ) : array();
	if ( ! $tree ) {
		return vp_default_header_menu();
	}
	$out = array();
	foreach ( $tree as $top ) {
		if ( ! $top->vp_children ) {
			$out[] = array( 'type' => 'link', 'label' => $top->title, 'href' => $top->url, 'target' => $top->target );
			continue;
		}
		$m = array( 'type' => 'mega', 'id' => 'm' . $top->ID, 'label' => $top->title, 'cats' => array(), 'foot' => null, 'promo' => null );
		foreach ( $top->vp_children as $c ) {
			$cls = array_filter( (array) $c->classes );
			if ( in_array( 'vp-promo', $cls, true ) ) {
				$parts      = array_map( 'trim', explode( '||', (string) $c->description ) );
				$m['promo'] = array(
					'icon'   => vp_icon_for( '', $cls, 'sparkles' ),
					'kicker' => $c->attr_title,
					'title'  => $c->title,
					'body'   => $parts[0] ?? '',
					'cta'    => $parts[1] ?? __( 'Learn more', 'vulopilot' ),
					'href'   => $c->url,
				);
				continue;
			}
			if ( in_array( 'vp-foot', $cls, true ) ) {
				$m['foot'] = array( 'label' => $c->title, 'href' => $c->url );
				continue;
			}
			$items = array();
			foreach ( $c->vp_children as $i ) {
				$items[] = array(
					'label' => $i->title,
					'href'  => $i->url,
					'desc'  => (string) $i->description,
					'icon'  => vp_icon_for( $i->url, (array) $i->classes ),
				);
			}
			$m['cats'][] = array(
				'id'    => 'c' . $c->ID,
				'title' => $c->title,
				'hint'  => (string) $c->description,
				'icon'  => vp_icon_for( '', $cls, 'sparkles' ),
				'items' => $items,
				'all'   => array( 'label' => $c->attr_title ? $c->attr_title : sprintf( /* translators: %s category */ __( 'All %s', 'vulopilot' ), strtolower( $c->title ) ), 'href' => $c->url ),
			);
		}
		if ( $m['cats'] ) {
			$out[] = $m;
		}
	}
	return $out;
}

/** Footer columns (from Appearance → Menus, or the defaults). */
function vp_footer_menu() {
	$menu = vp_menu_at( 'vp_footer' );
	$tree = $menu ? vp_menu_tree( $menu ) : array();
	if ( ! $tree ) {
		return vp_default_footer_menu();
	}
	$cols = array();
	foreach ( $tree as $top ) {
		$cols[] = array(
			'title' => $top->title,
			'row'   => in_array( 'vp-row-2', (array) $top->classes, true ) ? 2 : 1,
			'items' => array_map(
				function ( $i ) {
					return array( 'label' => $i->title, 'href' => $i->url );
				},
				$top->vp_children
			),
		);
	}
	return $cols;
}

/* -------------------------------------------------------------------------
 * Create the default menus in Appearance → Menus (used by the setup screen).
 * ---------------------------------------------------------------------- */

/** Add one item to a menu and return its id. */
function vp_add_menu_item( $menu_id, $parent, $title, $url, $args = array() ) {
	return wp_update_nav_menu_item(
		$menu_id,
		0,
		array(
			'menu-item-title'       => $title,
			// Root-relative ("/pricing/") so the menu keeps working if the site address changes; vp_url() adds the domain on output.
			'menu-item-url'         => $url,
			'menu-item-status'      => 'publish',
			'menu-item-type'        => 'custom',
			'menu-item-parent-id'   => $parent,
			'menu-item-description' => $args['desc'] ?? '',
			'menu-item-attr-title'  => $args['attr'] ?? '',
			'menu-item-classes'     => $args['class'] ?? '',
		)
	);
}

/** Build both menus from the defaults and assign them. Returns [header_id, footer_id]. */
function vp_create_default_menus() {
	$ids = array();
	foreach ( array( 'vp_header' => 'VuloPilot Header', 'vp_footer' => 'VuloPilot Footer' ) as $loc => $name ) {
		$existing = wp_get_nav_menu_object( $name );
		if ( $existing ) {
			wp_delete_nav_menu( $existing->term_id );
		}
		$ids[ $loc ] = wp_create_nav_menu( $name );
	}
	$h = $ids['vp_header'];
	foreach ( vp_default_header_menu() as $top ) {
		$tid = vp_add_menu_item( $h, 0, $top['label'], $top['href'] ?? '#' );
		if ( 'mega' !== $top['type'] ) {
			continue;
		}
		foreach ( $top['cats'] as $c ) {
			$cid = vp_add_menu_item( $h, $tid, $c['title'], $c['all']['href'], array( 'desc' => $c['hint'], 'attr' => $c['all']['label'], 'class' => 'vp-icon-' . $c['icon'] ) );
			foreach ( $c['items'] as $i ) {
				vp_add_menu_item( $h, $cid, $i['label'], $i['href'], array( 'desc' => $i['desc'] ?? '' ) );
			}
		}
		$p = $top['promo'];
		vp_add_menu_item( $h, $tid, $p['title'], $p['href'], array( 'desc' => $p['body'] . ' || ' . $p['cta'], 'attr' => $p['kicker'], 'class' => 'vp-promo vp-icon-' . $p['icon'] ) );
		vp_add_menu_item( $h, $tid, $top['foot']['label'], $top['foot']['href'], array( 'class' => 'vp-foot' ) );
	}
	$f = $ids['vp_footer'];
	foreach ( vp_default_footer_menu() as $col ) {
		$cid = vp_add_menu_item( $f, 0, $col['title'], '#', array( 'class' => 2 === $col['row'] ? 'vp-row-2' : '' ) );
		foreach ( $col['items'] as $i ) {
			vp_add_menu_item( $f, $cid, $i['label'], $i['href'] );
		}
	}
	$locs              = get_theme_mod( 'nav_menu_locations', array() );
	$locs['vp_header'] = $h;
	$locs['vp_footer'] = $f;
	set_theme_mod( 'nav_menu_locations', $locs );
	return $ids;
}
