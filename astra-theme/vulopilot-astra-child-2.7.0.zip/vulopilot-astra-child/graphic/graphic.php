<?php
/**
 * Graphic folder – loader.
 *
 * Everything that draws an animated graphic lives in this folder:
 *
 *   graphic/graphic.php        this file: loads the others, CSS/JS, the "Animated Graphic" block
 *   graphic/render.php         vp_mount() + the graphic shortcodes ([vp_graphic], [vp_<name>], [vp_shot] …)
 *   graphic/graphics.php       graphic names: old-name aliases and the list of PHP graphics
 *   graphic/page-graphics.php  helpers for the 40 scenes used by the solution / problem / use-case pages
 *   graphic/parts/             one PHP file per graphic (parts/classic = 2.5 versions, parts/scenes = scenes)
 *   graphic/prerender/         HTML for the graphics that still run on the React bundle
 *   graphic/block/             the "Animated Graphic" block (block name vulopilot/graphic)
 *   graphic/css/               vp-graphics.css, vp-page-graphics.css
 *   graphic/js/                vp-graphics.js (small widgets), vp-app.js (React bundle, only loaded when needed)
 *
 * Nothing used on live pages was renamed: shortcodes, block name, graphic names, CSS classes,
 * script/style handles and the vp_graphic_parts / vp_graphic_aliases filters work as before.
 *
 * @package VuloPilot
 */

defined( 'ABSPATH' ) || exit;

define( 'VP_GRAPHIC_DIR', VP_DIR . '/graphic' );
define( 'VP_GRAPHIC_URI', VP_URI . '/graphic' );

require VP_GRAPHIC_DIR . '/graphics.php';
require VP_GRAPHIC_DIR . '/page-graphics.php';
require VP_GRAPHIC_DIR . '/render.php';

/** Version string for a file in this folder (theme version + file time, so caches refresh on change). */
function vp_graphic_ver( $file ) {
	return VP_VERSION . '.' . filemtime( VP_GRAPHIC_DIR . '/' . $file );
}

/* -------------------------------------------------------------------------
 * Front end: CSS + JS for the graphics, and the React bundle (registered only)
 * ---------------------------------------------------------------------- */
add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'vp-graphics', VP_GRAPHIC_URI . '/css/vp-graphics.css', array( 'vp-motion' ), vp_graphic_ver( 'css/vp-graphics.css' ) );
		wp_enqueue_style( 'vp-page-graphics', VP_GRAPHIC_URI . '/css/vp-page-graphics.css', array( 'vp-graphics' ), vp_graphic_ver( 'css/vp-page-graphics.css' ) );
		wp_enqueue_script( 'vp-graphics', VP_GRAPHIC_URI . '/js/vp-graphics.js', array( 'vp-motion' ), vp_graphic_ver( 'js/vp-graphics.js' ), true );

		// React bundle: printed only when vp_mount() needs a graphic that has no PHP version.
		wp_register_script( 'vp-app', VP_GRAPHIC_URI . '/js/vp-app.js', array(), vp_graphic_ver( 'js/vp-app.js' ), true );
		wp_add_inline_script(
			'vp-app',
			'window.VP_DATA=' . wp_json_encode(
				array(
					'assets'  => vp_assets_url(),
					'screens' => wp_list_pluck( vp_screens(), 'src' ),
				)
			) . ';',
			'before'
		);
	},
	21
);

/* -------------------------------------------------------------------------
 * Block editor: same graphic styles inside the editor
 * ---------------------------------------------------------------------- */
add_action(
	'enqueue_block_assets',
	function () {
		if ( ! is_admin() ) {
			return;
		}
		wp_enqueue_style( 'vp-graphics', VP_GRAPHIC_URI . '/css/vp-graphics.css', array(), vp_graphic_ver( 'css/vp-graphics.css' ) );
		wp_enqueue_style( 'vp-page-graphics', VP_GRAPHIC_URI . '/css/vp-page-graphics.css', array(), vp_graphic_ver( 'css/vp-page-graphics.css' ) );
	}
);

/* -------------------------------------------------------------------------
 * "Animated Graphic" block (vulopilot/graphic). Needs vp-editor-data from inc/blocks.php.
 * ---------------------------------------------------------------------- */
add_action(
	'init',
	function () {
		register_block_type( VP_GRAPHIC_DIR . '/block' );
	},
	11
);
